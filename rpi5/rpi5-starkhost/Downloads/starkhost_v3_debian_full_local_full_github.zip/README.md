# StarkHost v3 – Debian Full Local AI Edition
Kompletní systém pro Raspberry Pi 5 (Debian host), s Home Assistant, Node-RED, MQTT, Waydroid a AIbotem (lokální LLM).