# STARCORE HIVE – Nasazení na fatalab

## Požadavky
- Bash 5+, Python 3.8+, sqlite3
- Volitelné: inotify-tools (apt-get install inotify-tools)

## Instalace

```bash
# 1. Rozbalit na server
scp starcore-hive-v1.0.zip root@10.0.0.37:/root/
unzip starcore-hive-v1.0.zip -d /root/

# 2. Spustit instalaci
cd /root/starcore-hive-release
bash install.sh

# 3. Spustit systém
systemctl start starcore-orchestrator
systemctl start starcore-dashboard

# 4. Sledovat terminálový dashboard
HIVE_DIR=/root/starcore/hive bash /root/starcore/hive/dashboard_terminal.sh

# 5. Otevřít HTTP dashboard (v prohlížeči)
http://10.0.0.37:7979
```

## Ovládání

```bash
# Stav všech služeb
systemctl status starcore-orchestrator starcore-dashboard

# Logy orchestrátoru (live)
journalctl -u starcore-orchestrator -f

# Logy konkrétního agenta
journalctl -u starcore-agent@inspector-1 -f

# Zastavit vše
systemctl stop starcore-orchestrator starcore-dashboard

# Přidat extra agenta (např. 2. inspector)
systemctl start starcore-agent@inspector-2

# Konfigurace počtu agentů a intervalů
nano /root/starcore/hive/config/agents.json
systemctl restart starcore-orchestrator
```

## Struktura

```
/root/starcore/hive/
├── registry.db          ← SQLite (WAL), centrální stav
├── orchestrator.py      ← Správce agentů + fronta
├── dashboard_http.py    ← HTTP dashboard na portu 7979
├── dashboard_terminal.sh← Terminálový přehled
├── schema.sql           ← DB schema
├── lib/
│   ├── db.sh           ← DB wrapper funkce
│   └── common.sh       ← Sdílené analytické funkce
├── agents/
│   └── agent-worker.sh ← Generický worker (všechny role)
├── config/
│   └── agents.json     ← Konfigurace rolí a intervalů
└── logs/{role}/        ← Logy každého agenta
```
