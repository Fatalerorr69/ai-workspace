#!/bin/bash
# ============================================================================
# STARCORE HIVE – dashboard_terminal.sh
# Lehký terminálový dashboard čtoucí stav přímo z registry.db.
# Překresluje se každých 10 sekund (nebo DASHBOARD_REFRESH sekund).
# Nevyžaduje žádné agenty – jen DB_PATH.
#
# Použití:
#   HIVE_DIR=/root/starcore/hive bash dashboard_terminal.sh
#   nebo se spoléhá na výchozí HIVE_DIR
# ============================================================================

HIVE_DIR="${HIVE_DIR:-/root/starcore/hive}"
DB_PATH="${DB_PATH:-$HIVE_DIR/registry.db}"
DASHBOARD_REFRESH="${DASHBOARD_REFRESH:-10}"
HTTP_PORT="${HTTP_PORT:-7979}"

# ── Barvy ───────────────────────────────────────────────────────────────────
if [[ -t 1 ]] && command -v tput &>/dev/null && tput colors &>/dev/null 2>&1; then
    C_RED='\033[0;31m'    C_GREEN='\033[0;32m'  C_YELLOW='\033[1;33m'
    C_BLUE='\033[0;34m'   C_CYAN='\033[0;36m'   C_MAGENTA='\033[0;35m'
    C_BOLD='\033[1m'      C_DIM='\033[2m'        C_NC='\033[0m'
else
    C_RED='' C_GREEN='' C_YELLOW='' C_BLUE=''
    C_CYAN='' C_MAGENTA='' C_BOLD='' C_DIM='' C_NC=''
fi

# ── Pomocné funkce ──────────────────────────────────────────────────────────
q() {
    # Spustí SQLite dotaz a vrátí výsledek (prázdný string pokud DB nedostupná)
    sqlite3 -batch -separator $'\t' "$DB_PATH" ".timeout 3000" "$1" 2>/dev/null
}

draw_bar() {
    # draw_bar <hodnota> <maximum> <šířka>
    local val="$1" max="$2" width="${3:-30}"
    [[ "${max:-0}" -le 0 ]] && max=1
    local filled=$(( val * width / max ))
    [[ $filled -gt $width ]] && filled=$width
    local empty=$(( width - filled ))
    local bar=""
    [[ $filled -gt 0 ]] && bar+=$(printf "%${filled}s" | tr ' ' '█')
    [[ $empty  -gt 0 ]] && bar+=$(printf "%${empty}s"  | tr ' ' '░')
    echo -n "$bar"
}

format_age() {
    local secs="${1:-0}"
    if   [[ $secs -lt 60   ]]; then echo "${secs}s"
    elif [[ $secs -lt 3600 ]]; then echo "$(( secs/60 ))m$(( secs%60 ))s"
    else echo "$(( secs/3600 ))h$(( (secs%3600)/60 ))m"
    fi
}

agent_status_color() {
    case "$1" in
        idle)     echo -n "${C_GREEN}" ;;
        working)  echo -n "${C_CYAN}" ;;
        starting) echo -n "${C_YELLOW}" ;;
        crashed)  echo -n "${C_RED}" ;;
        stopped)  echo -n "${C_DIM}" ;;
        *)        echo -n "${C_DIM}" ;;
    esac
}

severity_color() {
    case "$1" in
        error)         echo -n "${C_RED}" ;;
        warning)       echo -n "${C_YELLOW}" ;;
        auto_fixable)  echo -n "${C_CYAN}" ;;
        info)          echo -n "${C_DIM}" ;;
        *)             echo -n "${C_NC}" ;;
    esac
}

# ── Stav vykreslení ─────────────────────────────────────────────────────────
LAST_LINES=0
RUNNING=1
trap 'RUNNING=0; tput cnorm 2>/dev/null || true; echo; exit 0' SIGINT SIGTERM

tput civis 2>/dev/null || true   # skrýt kurzor

# ── Hlavní smyčka ───────────────────────────────────────────────────────────
while [[ $RUNNING -eq 1 ]]; do

    # ── Čtení z DB ──────────────────────────────────────────────────────────
    NOW=$(date +%s)
    DB_OK=1
    [[ -f "$DB_PATH" ]] || DB_OK=0

    if [[ $DB_OK -eq 1 ]]; then
        # Agenti
        AGENT_ROWS=$(q "SELECT agent_id, role, status, last_heartbeat,
                               tasks_completed, tasks_failed, current_task_id
                        FROM agents ORDER BY role, agent_id;")

        # Tasks souhrn
        T_PENDING=$(q "SELECT COUNT(*) FROM tasks WHERE status='pending';")
        T_CLAIMED=$(q "SELECT COUNT(*) FROM tasks WHERE status='claimed';")
        T_DONE=$(q    "SELECT COUNT(*) FROM tasks WHERE status='done';")
        T_FAILED=$(q  "SELECT COUNT(*) FROM tasks WHERE status='failed';")
        T_TOTAL=$(q   "SELECT COUNT(*) FROM tasks;")

        # Pending per role
        PENDING_ROLES=$(q "SELECT target_role, COUNT(*) FROM tasks
                           WHERE status='pending' GROUP BY target_role ORDER BY target_role;")

        # Findings souhrn
        F_SYNTAX=$(q  "SELECT COUNT(*) FROM findings WHERE finding_type='syntax_error'    AND resolved_at IS NULL;")
        F_SEC=$(q     "SELECT COUNT(*) FROM findings WHERE finding_type='security_warning' AND resolved_at IS NULL;")
        F_DEP=$(q     "SELECT COUNT(*) FROM findings WHERE finding_type='missing_dep'      AND resolved_at IS NULL;")
        F_DUP=$(q     "SELECT COUNT(*) FROM findings WHERE finding_type='duplicate'        AND resolved_at IS NULL;")
        F_MANUAL=$(q  "SELECT COUNT(*) FROM findings WHERE finding_type='needs_manual_review' AND resolved_at IS NULL;")
        F_TOTAL=$(q   "SELECT COUNT(*) FROM findings WHERE resolved_at IS NULL;")
        F_RESOLVED=$(q "SELECT COUNT(*) FROM findings WHERE resolved_at IS NOT NULL;")

        # Soubory
        FILES_TOTAL=$(q "SELECT COUNT(*) FROM files WHERE status='active';")
        FILES_SH=$(q    "SELECT COUNT(*) FROM files WHERE file_type='sh'   AND status='active';")
        FILES_PY=$(q    "SELECT COUNT(*) FROM files WHERE file_type='py'   AND status='active';")
        FILES_MD=$(q    "SELECT COUNT(*) FROM files WHERE file_type='md'   AND status='active';")

        # Library
        LIB_COUNT=$(q   "SELECT COUNT(*) FROM library;")

        SCHEMA_VER=$(q  "SELECT version FROM schema_version LIMIT 1;")
    fi

    # ── Přemazání předchozího výstupu ───────────────────────────────────────
    if [[ $LAST_LINES -gt 0 ]] && [[ -t 1 ]]; then
        tput cuu "$LAST_LINES" 2>/dev/null || true
        tput ed  2>/dev/null  || true
    fi

    # ── Sestavení výstupu do proměnné (atomický flush na konci) ─────────────
    OUT=""
    nl=$'\n'

    SEP_THICK="════════════════════════════════════════════════════════════════"
    SEP_THIN="────────────────────────────────────────────────────────────────"

    # Hlavička
    OUT+="${C_BOLD}${C_BLUE}╔${SEP_THICK}╗${C_NC}${nl}"
    OUT+="${C_BLUE}║${C_NC} ${C_BOLD}STARCORE HIVE – Live Dashboard${C_NC}  ${C_DIM}$(date '+%Y-%m-%d %H:%M:%S')  •  DB schema v${SCHEMA_VER:-?}${C_NC}${nl}"
    OUT+="${C_BLUE}║${C_NC} ${C_DIM}DB: $DB_PATH  •  HTTP: http://localhost:${HTTP_PORT}${C_NC}${nl}"
    OUT+="${C_BLUE}╠${SEP_THICK}╣${C_NC}${nl}"

    if [[ $DB_OK -eq 0 ]]; then
        OUT+="${C_RED} ✘ DB není dostupná: $DB_PATH${C_NC}${nl}"
        OUT+="${C_BLUE}╚${SEP_THICK}╝${C_NC}${nl}"
        OUT+="${C_DIM}Ctrl+C pro ukončení  •  refresh za ${DASHBOARD_REFRESH}s${C_NC}${nl}"
        echo -en "$OUT"
        LAST_LINES=$(echo -e "$OUT" | wc -l)
        sleep "$DASHBOARD_REFRESH"
        continue
    fi

    # ── Sekce: Agenti ────────────────────────────────────────────────────────
    OUT+="${C_BOLD}${C_BLUE}║${C_NC} ${C_BOLD}AGENTI${C_NC}${nl}"
    if [[ -z "$AGENT_ROWS" ]]; then
        OUT+="${C_BLUE}║${C_NC}  ${C_DIM}(žádní registrovaní agenti)${C_NC}${nl}"
    else
        while IFS=$'\t' read -r aid role status hb done failed curtask; do
            [[ -z "$aid" ]] && continue
            hb_age=$(( NOW - ${hb:-0} ))
            age_str=$(format_age "$hb_age")
            sc=$(agent_status_color "$status")
            task_info=""
            [[ -n "$curtask" && "$curtask" != "NULL" ]] && task_info=" ${C_DIM}[task#${curtask}]${C_NC}"

            OUT+="$(printf "${C_BLUE}║${C_NC}  ${C_BOLD}%-18s${C_NC} ${sc}%-10s${C_NC} " "$aid" "$status")"
            OUT+="$(printf "${C_DIM}hb:%-5s${C_NC} done:${C_GREEN}%4d${C_NC} fail:${C_RED}%3d${C_NC}%s\n" \
                "$age_str" "${done:-0}" "${failed:-0}" "$task_info")"
        done <<< "$AGENT_ROWS"
    fi
    OUT+="${C_BLUE}╠${SEP_THIN}╣${C_NC}${nl}"

    # ── Sekce: Fronta úkolů ──────────────────────────────────────────────────
    OUT+="${C_BOLD}${C_BLUE}║${C_NC} ${C_BOLD}FRONTA ÚKOLŮ${C_NC}${nl}"
    # Progress bar: done / total
    bar_done=$(draw_bar "${T_DONE:-0}" "${T_TOTAL:-1}" 35)
    OUT+="${C_BLUE}║${C_NC}  ${C_GREEN}${bar_done}${C_NC} ${T_DONE:-0}/${T_TOTAL:-0} hotovo${nl}"
    OUT+="$(printf "${C_BLUE}║${C_NC}  pending:${C_YELLOW}%5d${C_NC}  claimed:${C_CYAN}%4d${C_NC}  done:${C_GREEN}%5d${C_NC}  failed:${C_RED}%4d${C_NC}\n" \
        "${T_PENDING:-0}" "${T_CLAIMED:-0}" "${T_DONE:-0}" "${T_FAILED:-0}")"

    if [[ -n "$PENDING_ROLES" ]]; then
        OUT+="${C_BLUE}║${C_NC}  ${C_DIM}Pending dle role:${C_NC}"
        while IFS=$'\t' read -r role cnt; do
            [[ -z "$role" ]] && continue
            OUT+=" ${C_BOLD}${role}${C_NC}:${C_YELLOW}${cnt}${C_NC}"
        done <<< "$PENDING_ROLES"
        OUT+="${nl}"
    fi
    OUT+="${C_BLUE}╠${SEP_THIN}╣${C_NC}${nl}"

    # ── Sekce: Findings ──────────────────────────────────────────────────────
    OUT+="${C_BOLD}${C_BLUE}║${C_NC} ${C_BOLD}FINDINGS${C_NC}  ${C_DIM}(nezvyřešených: ${F_TOTAL:-0}  •  vyřešených: ${F_RESOLVED:-0})${C_NC}${nl}"
    bar_res=$(draw_bar "${F_RESOLVED:-0}" "$(( ${F_TOTAL:-0} + ${F_RESOLVED:-0} ))" 35)
    OUT+="${C_BLUE}║${C_NC}  ${C_GREEN}${bar_res}${C_NC} vyřešeno${nl}"
    OUT+="$(printf "${C_BLUE}║${C_NC}  syntax:${C_RED}%3d${C_NC}  security:${C_YELLOW}%3d${C_NC}  missing_dep:${C_YELLOW}%3d${C_NC}  dup:${C_DIM}%3d${C_NC}  manual:${C_RED}%3d${C_NC}\n" \
        "${F_SYNTAX:-0}" "${F_SEC:-0}" "${F_DEP:-0}" "${F_DUP:-0}" "${F_MANUAL:-0}")"
    OUT+="${C_BLUE}╠${SEP_THIN}╣${C_NC}${nl}"

    # ── Sekce: Index souborů + Library ───────────────────────────────────────
    OUT+="${C_BOLD}${C_BLUE}║${C_NC} ${C_BOLD}INDEX SOUBORŮ${C_NC}  celkem:${C_GREEN}${FILES_TOTAL:-0}${C_NC}  │  "
    OUT+="${C_DIM}.sh:${FILES_SH:-0}  .py:${FILES_PY:-0}  .md:${FILES_MD:-0}${C_NC}${nl}"
    OUT+="${C_BOLD}${C_BLUE}║${C_NC} ${C_BOLD}KNIHOVNA${C_NC}  ${C_DIM}vygenerovaných skriptů: ${C_GREEN}${LIB_COUNT:-0}${C_NC}${nl}"
    OUT+="${C_BLUE}╚${SEP_THICK}╝${C_NC}${nl}"

    # Patička
    OUT+="${C_DIM}Ctrl+C pro ukončení  •  refresh za ${DASHBOARD_REFRESH}s  •  detail: http://localhost:${HTTP_PORT}${C_NC}${nl}"

    # ── Atomický výpis ───────────────────────────────────────────────────────
    echo -en "$OUT"
    LAST_LINES=$(echo -e "$OUT" | wc -l)

    sleep "$DASHBOARD_REFRESH"
done

tput cnorm 2>/dev/null || true
