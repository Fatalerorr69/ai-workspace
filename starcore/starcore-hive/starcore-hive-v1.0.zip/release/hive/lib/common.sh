#!/bin/bash
# ============================================================================
# STARCORE HIVE – lib/common.sh
# Sdílené funkce pro všechny agenty. SOURCE-uje se z agent-worker.sh.
# Vyžaduje: DB_PATH, AGENT_ID, AGENT_ROLE, HIVE_DIR nastaveny před source.
# ============================================================================

# Povinné proměnné – selžeme hlasitě, pokud chybí.
: "${DB_PATH:?common.sh: DB_PATH musí být nastaven}"
: "${AGENT_ID:?common.sh: AGENT_ID musí být nastaven}"
: "${AGENT_ROLE:?common.sh: AGENT_ROLE musí být nastaven}"
: "${HIVE_DIR:?common.sh: HIVE_DIR musí být nastaven}"

LOG_DIR="${LOG_DIR:-$HIVE_DIR/logs/$AGENT_ROLE}"
mkdir -p "$LOG_DIR"

# Max počet oprav jednoho souboru za hodinu před aktivací circuit breakeru.
CIRCUIT_BREAKER_MAX="${CIRCUIT_BREAKER_MAX:-5}"
CIRCUIT_BREAKER_WINDOW="${CIRCUIT_BREAKER_WINDOW:-3600}"

# ============================================================================
# LOGOVÁNÍ
# ============================================================================

# Barvy (zkontrolujeme, jestli terminál podporuje barvy)
if [[ -t 1 ]] && command -v tput &>/dev/null && tput colors &>/dev/null; then
    _C_RED='\033[0;31m'
    _C_GREEN='\033[0;32m'
    _C_YELLOW='\033[1;33m'
    _C_BLUE='\033[0;34m'
    _C_CYAN='\033[0;36m'
    _C_MAGENTA='\033[0;35m'
    _C_DIM='\033[2m'
    _C_BOLD='\033[1m'
    _C_NC='\033[0m'
else
    _C_RED='' _C_GREEN='' _C_YELLOW='' _C_BLUE=''
    _C_CYAN='' _C_MAGENTA='' _C_DIM='' _C_BOLD='' _C_NC=''
fi

_log_line() {
    local level="$1" color="$2" msg="$3"
    local ts; ts=$(date '+%Y-%m-%d %H:%M:%S')
    local line="[$ts][$AGENT_ID][$level] $msg"
    # Na stdout s barvou
    echo -e "${color}${line}${_C_NC}"
    # Do logovacího souboru (bez ANSI kódů)
    echo "$line" >> "$LOG_DIR/${AGENT_ID}.log"
}

log_info()  { _log_line "INFO " "$_C_CYAN"    "$*"; }
log_ok()    { _log_line "OK   " "$_C_GREEN"   "$*"; }
log_warn()  { _log_line "WARN " "$_C_YELLOW"  "$*"; }
log_error() { _log_line "ERROR" "$_C_RED"     "$*"; }
log_debug() { [[ "${DEBUG:-0}" == "1" ]] && _log_line "DEBUG" "$_C_DIM" "$*" || true; }

# ============================================================================
# KONTROLA SYNTAXE
# Vrací 0 = OK, 1 = syntax error, 2 = nástroj nedostupný
# ============================================================================
check_syntax() {
    local file="$1"
    [[ -f "$file" ]] || return 2
    case "$file" in
        *.sh)
            bash -n "$file" 2>/dev/null && return 0 || return 1
            ;;
        *.py)
            if command -v python3 &>/dev/null; then
                python3 -m py_compile "$file" 2>/dev/null && return 0 || return 1
            fi
            return 2
            ;;
        *.js)
            if command -v node &>/dev/null; then
                node -c "$file" 2>/dev/null && return 0 || return 1
            fi
            return 2
            ;;
        *.json)
            if command -v python3 &>/dev/null; then
                python3 -c "import json, sys; json.load(open(sys.argv[1]))" "$file" 2>/dev/null \
                    && return 0 || return 1
            fi
            return 2
            ;;
        *.yaml|*.yml)
            if command -v python3 &>/dev/null; then
                python3 -c "import yaml, sys; yaml.safe_load(open(sys.argv[1]))" "$file" 2>/dev/null \
                    && return 0 || return 1
            fi
            return 2
            ;;
        *)
            return 0  # neznámý typ, neprovádíme syntax check
            ;;
    esac
}
export -f check_syntax

# ============================================================================
# KONTROLA ZÁVISLOSTÍ (pouze .sh)
# Kontroluje první slovo každého neprázdného, nekomentářového řádku.
# Vrací seznam "Chybí závislost: cmd (v souboru)" na stdout.
# ============================================================================
check_dependencies() {
    local file="$1"
    [[ -f "$file" && "$file" == *.sh ]] || return 0

    # Shromáždíme lokálně definované funkce v tomto souboru (typicky "log",
    # "check_*" apod.) – jejich volání NENÍ chybějící systémová závislost.
    local own_fns
    own_fns=$(grep -oE '^[[:space:]]*[A-Za-z_][A-Za-z0-9_]*[[:space:]]*\(\)' "$file" 2>/dev/null \
        | sed 's/[[:space:]]*()$//' | sed 's/^[[:space:]]*//')

    local cmd line
    while IFS= read -r line; do
        # Trim leading whitespace
        line="${line#"${line%%[![:space:]]*}"}"
        [[ -z "$line" || "$line" == \#* ]] && continue
        # Case-label (končí ')' bez mezer) – není příkaz
        [[ "$line" =~ ^\S+\)$ ]] && continue
        # Vzít první slovo
        cmd="${line%%[[:space:]]*}"
        cmd="${cmd%%[;|()*]*}"
        [[ -z "$cmd" ]] && continue
        # Přeskočit cesty, přiřazení proměnných, wildcards
        [[ "$cmd" == */* || "$cmd" == *=* || "$cmd" == "*" ]] && continue
        # Bash built-ins a klíčová slova
        case "$cmd" in
            if|then|else|elif|fi|case|esac|for|while|do|done|function|return|exit|\
            echo|printf|read|cd|pwd|export|source|exec|eval|set|trap|wait|sleep|\
            time|ulimit|umask|unset|shift|getopts|local|declare|typeset|readonly|\
            alias|unalias|bg|fg|jobs|kill|nice|nohup|suspend|true|false|test|in|\
            \{|\}|break|continue|let|select)
                continue ;;
        esac
        # Přeskočit lokální funkce souboru
        if [[ -n "$own_fns" ]] && grep -qxF "$cmd" <<< "$own_fns" 2>/dev/null; then
            continue
        fi
        # Zkontrolovat dostupnost
        if ! command -v "$cmd" &>/dev/null; then
            echo "Chybí závislost: $cmd (v $file)"
        fi
    done < "$file"
}
export -f check_dependencies

# ============================================================================
# DETEKCE BEZPEČNOSTNÍCH VZORŮ (bash skripty)
# Vrací seznam nalezených rizik na stdout (prázdno = vše OK).
# ============================================================================
check_security_patterns() {
    local file="$1"
    [[ -f "$file" && "$file" == *.sh ]] || return 0

    local issues=()

    # eval s proměnnou – potenciálně nebezpečná dynamická evaluace
    if grep -qnE 'eval\s+\$' "$file" 2>/dev/null; then
        local ln; ln=$(grep -nE 'eval\s+\$' "$file" | head -3 | cut -d: -f1 | tr '\n' ',')
        issues+=("eval s proměnnou (řádky: ${ln%,})")
    fi

    # curl/wget piped do bash – klasická RCE sekvence
    if grep -qnE '(curl|wget).+\|\s*(ba)?sh' "$file" 2>/dev/null; then
        issues+=("curl/wget piped do bash (potenciální RCE)")
    fi

    # rm -rf s proměnnou bez uvozovek – nebezpečné mazání
    if grep -qnE 'rm\s+-[rRf]+\s+\$[^"(]' "$file" 2>/dev/null; then
        issues+=("rm -rf s neouvozovkovanou proměnnou")
    fi

    # chmod 777 – přílišná oprávnění
    if grep -qnE 'chmod\s+(777|a\+rwx)' "$file" 2>/dev/null; then
        issues+=("chmod 777 / a+rwx")
    fi

    # Hardcoded credentialy (API key, password ve skriptu)
    if grep -qiE '(api_key|password|secret|token)\s*=\s*["\047][^"\047]{4,}' "$file" 2>/dev/null; then
        issues+=("potenciálně hardcoded credential/token")
    fi

    if [[ ${#issues[@]} -gt 0 ]]; then
        for iss in "${issues[@]}"; do
            echo "$iss"
        done
    fi
}
export -f check_security_patterns

# ============================================================================
# ZJIŠTĚNÍ TYPU SOUBORU
# Vrací krátký tag: sh, py, js, json, yaml, md, conf, service, cron, other
# ============================================================================
get_file_type() {
    local file="$1"
    case "$file" in
        *.sh)      echo "sh" ;;
        *.py)      echo "py" ;;
        *.js)      echo "js" ;;
        *.json)    echo "json" ;;
        *.yaml|*.yml) echo "yaml" ;;
        *.md)      echo "md" ;;
        *.conf|*.cfg|*.ini) echo "conf" ;;
        *.service) echo "service" ;;
        *.cron)    echo "cron" ;;
        *.txt)     echo "txt" ;;
        *)         echo "other" ;;
    esac
}
export -f get_file_type

# ============================================================================
# AUTO-OPRAVA (REPAIRER ROLE)
# Provede bezpečné, deterministické opravy. Nikdy nespustí soubor jako kód.
# Vrací 0 = něco opraveno, 1 = nic k opravě, 2 = soubor nelze opravit
# ============================================================================
auto_repair_file() {
    local file="$1" dry_run="${2:-0}"
    local repaired=0

    [[ -f "$file" ]] || return 2
    [[ -r "$file" ]] || return 2

    # BEZPEČNOSTNÍ CHECK: Nikdy neopravujeme soubory mimo povolené kořenové adresáře.
    local safe=0
    for allowed_root in "${ALLOWED_REPAIR_ROOTS[@]:-/root/starcore /opt}"; do
        if [[ "$file" == "$allowed_root"* ]]; then
            safe=1; break
        fi
    done
    if [[ $safe -eq 0 ]]; then
        log_warn "auto_repair: $file je mimo ALLOWED_REPAIR_ROOTS, přeskakuji"
        return 2
    fi

    [[ -w "$file" ]] || { log_warn "auto_repair: $file není zapisovatelný"; return 2; }

    local repairs=()

    # 1) Chybí shebang v .sh souboru
    if [[ "$file" == *.sh ]]; then
        if ! head -1 "$file" | grep -q '^#!'; then
            repairs+=("doplnit shebang")
            if [[ "$dry_run" -eq 0 ]]; then
                sed -i '1i #!/bin/bash' "$file" && repaired=1
            fi
        fi
    fi

    # 2) CRLF konce řádků (Windows → Unix)
    if grep -qU $'\r' "$file" 2>/dev/null; then
        repairs+=("CRLF → LF")
        if [[ "$dry_run" -eq 0 ]]; then
            sed -i 's/\r$//' "$file" && repaired=1
        fi
    fi

    # 3) Chybí spustitelný bit u .sh souboru
    if [[ "$file" == *.sh && ! -x "$file" ]]; then
        repairs+=("nastavit +x")
        if [[ "$dry_run" -eq 0 ]]; then
            chmod +x "$file" && repaired=1
        fi
    fi

    if [[ ${#repairs[@]} -gt 0 ]]; then
        local repair_desc; repair_desc=$(IFS=', '; echo "${repairs[*]}")
        if [[ "$dry_run" -eq 1 ]]; then
            log_info "auto_repair [DRY-RUN]: $file → by se opravilo: $repair_desc"
        else
            log_ok "auto_repair: $file → opraveno: $repair_desc"
        fi
        return 0
    fi
    return 1
}
export -f auto_repair_file

# ============================================================================
# CIRCUIT BREAKER PRO REPAIRER
# Vrací 0 = OK, lze opravovat; 1 = přerušovač aktivní (příliš mnoho pokusů)
# ============================================================================
circuit_breaker_check() {
    local file_path="$1"
    local count
    count=$(db_repair_attempt_count "$file_path" "$CIRCUIT_BREAKER_WINDOW")
    if [[ "${count:-0}" -ge "$CIRCUIT_BREAKER_MAX" ]]; then
        log_warn "circuit_breaker: $file_path měl ${count} oprav za posledních ${CIRCUIT_BREAKER_WINDOW}s – blokuji dalšíopravy"
        return 1
    fi
    return 0
}
export -f circuit_breaker_check

# ============================================================================
# EXTRAKCE METADAT SOUBORU
# Vrací asociativní pole jako "key=value" řádky na stdout.
# ============================================================================
extract_file_metadata() {
    local file="$1"
    [[ -f "$file" ]] || return 1

    local size mtime hash preview ftype
    size=$(stat -c%s "$file" 2>/dev/null || echo "0")
    mtime=$(stat -c%Y "$file" 2>/dev/null || echo "0")
    ftype=$(get_file_type "$file")

    # Hash jen u souborů do 50 MB (větší by zdržovaly)
    if [[ "${size:-0}" -lt 52428800 ]]; then
        hash=$(md5sum "$file" 2>/dev/null | cut -d' ' -f1)
    else
        hash="too_large"
    fi

    # Náhled prvních 500 znaků (bezpečně bez spouštění obsahu)
    preview=$(head -c 500 "$file" 2>/dev/null | tr -d '\0' | tr '\n' ' ')

    echo "size=$size"
    echo "mtime=$mtime"
    echo "hash=$hash"
    echo "file_type=$ftype"
    echo "preview=$preview"
}
export -f extract_file_metadata

# ============================================================================
# HEARTBEAT SMYČKA (spustí se na pozadí, pravidelně aktualizuje DB)
# Použití: start_heartbeat_loop [interval_sek]
# ============================================================================
start_heartbeat_loop() {
    local interval="${1:-15}"
    (
        while true; do
            sleep "$interval"
            db_heartbeat "$AGENT_ID" "${CURRENT_STATUS:-idle}" "${CURRENT_TASK_ID:-NULL}" 2>/dev/null
        done
    ) &
    HEARTBEAT_PID=$!
    export HEARTBEAT_PID
    log_debug "Heartbeat smyčka spuštěna (PID: $HEARTBEAT_PID, interval: ${interval}s)"
}

stop_heartbeat_loop() {
    if [[ -n "${HEARTBEAT_PID:-}" ]]; then
        kill "$HEARTBEAT_PID" 2>/dev/null || true
        log_debug "Heartbeat smyčka ukončena (PID: $HEARTBEAT_PID)"
    fi
}

# ============================================================================
# SIGNAL HANDLER (pro čisté ukončení agenta)
# ============================================================================
agent_cleanup() {
    log_info "Přijat signál ukončení, čistím po sobě..."
    stop_heartbeat_loop
    # Označit aktuálně zpracovávaný úkol jako failed, aby šel znovu zpracovat
    if [[ -n "${CURRENT_TASK_ID:-}" && "$CURRENT_TASK_ID" != "NULL" ]]; then
        db_fail_task "$CURRENT_TASK_ID" "Agent $AGENT_ID byl ukončen (SIGTERM/SIGINT)" 2>/dev/null
    fi
    db_heartbeat "$AGENT_ID" "stopped" "NULL" 2>/dev/null
    log_info "Agent $AGENT_ID ukončen."
    exit 0
}
