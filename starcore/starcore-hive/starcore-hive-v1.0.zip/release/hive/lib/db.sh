#!/bin/bash
# ============================================================================
# STARCORE HIVE – lib/db.sh
# Sdílené funkce pro práci s registry.db (SQLite).
# Tento soubor se SOURCE-uje z agent-worker.sh a orchestrátoru, nikdy se
# nespouští samostatně.
# ============================================================================

# Vyžaduje, aby volající skript měl nastavenou proměnnou DB_PATH před source.
: "${DB_PATH:?lib/db.sh: proměnná DB_PATH musí být nastavena před source}"

# Jak dlouho (sekund) může mít úkol status='claimed', než ho považujeme za
# osiřelý (agent spadl/zamrzl) a uvolníme ho zpět do 'pending'.
CLAIM_TIMEOUT_SECONDS="${CLAIM_TIMEOUT_SECONDS:-300}"

# Jak dlouho (sekund) bez heartbeatu, než agenta považujeme za mrtvý/crashed.
AGENT_STALE_SECONDS="${AGENT_STALE_SECONDS:-60}"

# ---------------------------------------------------------------------------
# Interní helper: spustí SQL přes sqlite3 s busy_timeout a vrátí výstup.
# Používá -separator a -batch, aby výstup byl strojově předvídatelný.
#
# Důležité: PRAGMA busy_timeout se nastavuje na začátku KAŽDÉHO volání,
# protože každé spuštění `sqlite3 ...` je nové připojení (pragma se
# nepřenáší mezi proces). I tak může SQLite vzácně vrátit "database is
# locked" (např. při velmi krátkém okně mezi BEGIN IMMEDIATE dvou procesů),
# proto navíc retry na úrovni bashe s krátkým jitterem.
# ---------------------------------------------------------------------------
_db_exec() {
    local sql="$*"
    local attempt=0
    local max_attempts=5
    local output rc

    while (( attempt < max_attempts )); do
        # Pozn.: používáme dot-command ".timeout" (heredoc), NE
        # "PRAGMA busy_timeout=5000;" jako součást SQL stringu -- PRAGMA
        # busy_timeout vypisuje svou nastavenou hodnotu jako řádek výstupu,
        # což by kontaminovalo výsledky SELECTů (zjištěno testem).
        output=$(sqlite3 -batch -separator $'\t' "$DB_PATH" <<EOF 2>&1
.timeout 5000
$sql
EOF
)
        rc=$?
        if [[ $rc -eq 0 ]]; then
            echo "$output"
            return 0
        fi
        if echo "$output" | grep -qi "database is locked\|database is busy"; then
            attempt=$(( attempt + 1 ))
            # krátký náhodný backoff (10-60 ms), aby se souběžné procesy "rozfázovaly"
            sleep "0.0$(( (RANDOM % 5) + 1 ))"
            continue
        fi
        # jiná chyba než zámek -> vypsat na stderr a vzdát to
        echo "$output" >&2
        return $rc
    done

    echo "_db_exec: vzdáno po $max_attempts pokusech (database locked): $sql" >&2
    return 1
}

db_check_available() {
    command -v sqlite3 &>/dev/null || { echo "FATAL: sqlite3 není dostupné" >&2; return 1; }
    [[ -f "$DB_PATH" ]] || { echo "FATAL: $DB_PATH neexistuje (spusť db_init nebo schema.sql)" >&2; return 1; }
    return 0
}

# ---------------------------------------------------------------------------
# db_init – vytvoří DB ze schema.sql, pokud ještě neexistuje. Idempotentní.
# Použití: db_init /cesta/k/schema.sql
# ---------------------------------------------------------------------------
db_init() {
    local schema_file="$1"
    [[ -f "$schema_file" ]] || { echo "FATAL: schema soubor nenalezen: $schema_file" >&2; return 1; }
    mkdir -p "$(dirname "$DB_PATH")"
    sqlite3 -batch "$DB_PATH" < "$schema_file"
}

# ---------------------------------------------------------------------------
# db_release_expired_claims – vrátí osiřelé 'claimed' úkoly zpět na 'pending'.
# Měl by ji volat orchestrátor periodicky (ne každý agent furt znovu).
# ---------------------------------------------------------------------------
db_release_expired_claims() {
    local now; now=$(date +%s)
    local cutoff=$(( now - CLAIM_TIMEOUT_SECONDS ))
    _db_exec "
        UPDATE tasks
        SET status = 'pending', claimed_by = NULL, claimed_at = NULL
        WHERE status = 'claimed' AND claimed_at < $cutoff;
    "
}

# ---------------------------------------------------------------------------
# db_add_task – vloží nový úkol do fronty.
# Použití: db_add_task <type> <target_role> <payload_json> [priority]
# Vrací: id nově vytvořeného úkolu (echo na stdout)
# ---------------------------------------------------------------------------
db_add_task() {
    local type="$1" target_role="$2" payload_json="$3" priority="${4:-5}"
    # escapovat jednoduché uvozovky v JSON payloadu pro SQL literal
    local escaped_payload="${payload_json//\'/\'\'}"
    _db_exec "
        INSERT INTO tasks (type, target_role, payload_json, priority)
        VALUES ('$type', '$target_role', '$escaped_payload', $priority);
        SELECT last_insert_rowid();
    " | tail -1
}

# ---------------------------------------------------------------------------
# db_claim_task – ATOMICKY vyzvedne jeden pending úkol pro danou roli.
# Použití: db_claim_task <role> <agent_id>
# Vrací: "id<TAB>type<TAB>payload_json" na stdout, nebo nic pokud žádný úkol.
#
# Atomicita: SQLite serializuje zápisy přes jeden spojený příkaz v transakci
# s podmínkou "WHERE status='pending' ... LIMIT 1" + okamžitý UPDATE ve stejné
# transakci. Díky busy_timeout se souběžné volání z více agentů jen na chvíli
# zablokuje a počká, ne že by úkol dostali dva agenti najednou.
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# db_claim_task – ATOMICKY vyzvedne jeden pending úkol pro danou roli.
# Použití: db_claim_task <role> <agent_id>
# Vrací: "id<TAB>type<TAB>payload_json" na stdout, nebo nic pokud žádný úkol.
#
# Atomicita: jediný UPDATE ... RETURNING v rámci BEGIN IMMEDIATE transakce.
# Použití RETURNING (SQLite 3.35+) je klíčové: dřívější verze dělala
# UPDATE a pak samostatný SELECT podle (agent_id, claimed_at), což při
# dvou claimech ze stejného agenta ve stejné sekundě omylem vracelo i
# PŘEDCHOZÍ už zabraný úkol (zjištěno souběžnostním testem). RETURNING
# vrací přesně ten řádek, který tento konkrétní UPDATE skutečně změnil –
# pokud UPDATE nic nenašel (žádný pending úkol), vrátí se prázdno.
# ---------------------------------------------------------------------------
db_claim_task() {
    local role="$1" agent_id="$2"
    local now; now=$(date +%s)

    _db_exec "
        BEGIN IMMEDIATE;
        UPDATE tasks
        SET status = 'claimed', claimed_by = '$agent_id', claimed_at = $now
        WHERE id = (
            SELECT id FROM tasks
            WHERE target_role = '$role' AND status = 'pending'
            ORDER BY priority ASC, created_at ASC
            LIMIT 1
        )
        RETURNING id, type, payload_json;
        COMMIT;
    " 2>/dev/null
}

# ---------------------------------------------------------------------------
# db_complete_task – označí úkol jako úspěšně dokončený.
# ---------------------------------------------------------------------------
db_complete_task() {
    local task_id="$1"
    _db_exec "
        UPDATE tasks
        SET status = 'done', completed_at = strftime('%s','now')
        WHERE id = $task_id;
    "
}

# ---------------------------------------------------------------------------
# db_fail_task – zaznamená chybu; pokud retry_count < max_retries, vrátí úkol
# zpět na 'pending' (++retry_count), jinak ho trvale označí jako 'failed'
# a vytvoří finding typu needs_manual_review.
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# db_fail_task – zaznamená chybu po neúspěšném pokusu o zpracování úkolu.
# Sémantika max_retries: CELKOVÝ počet povolených pokusů (ne "retry navíc").
# Tzn. max_retries=3 znamená, že úkol smí selhat 3× celkem, než přejde na
# trvalý stav 'failed' a vytvoří se finding pro ruční kontrolu.
# ---------------------------------------------------------------------------
db_fail_task() {
    local task_id="$1" error_msg="$2"
    local escaped_err="${error_msg//\'/\'\'}"

    local retry_info
    retry_info=$(_db_exec "SELECT retry_count, max_retries, type, target_role FROM tasks WHERE id = $task_id;")
    local retry_count max_retries ttype trole
    IFS=$'\t' read -r retry_count max_retries ttype trole <<< "$retry_info"
    retry_count="${retry_count:-0}"
    max_retries="${max_retries:-3}"

    # Tento neúspěch je pokus číslo (retry_count + 1). Pokud jsme tím
    # vyčerpali povolený počet pokusů, jde úkol trvale do 'failed'.
    if (( retry_count + 1 < max_retries )); then
        _db_exec "
            UPDATE tasks
            SET status = 'pending', claimed_by = NULL, claimed_at = NULL,
                retry_count = retry_count + 1, last_error = '$escaped_err'
            WHERE id = $task_id;
        "
    else
        _db_exec "
            UPDATE tasks
            SET status = 'failed', completed_at = strftime('%s','now'),
                retry_count = retry_count + 1, last_error = '$escaped_err'
            WHERE id = $task_id;
        "
        db_record_finding "task:$task_id" "$trole" "needs_manual_review" "error" \
            "Úkol #$task_id (typ: $ttype) selhal po $max_retries pokusech: $error_msg"
    fi
}

# ---------------------------------------------------------------------------
# db_record_finding – zapíše nález (chyba/varování/duplikát...) k souboru.
# Použití: db_record_finding <file_path> <agent_role> <finding_type> <severity> <message>
# ---------------------------------------------------------------------------
db_record_finding() {
    local file_path="$1" agent_role="$2" finding_type="$3" severity="$4" message="$5"
    local esc_path="${file_path//\'/\'\'}"
    local esc_msg="${message//\'/\'\'}"
    _db_exec "
        INSERT INTO findings (file_path, agent_role, finding_type, severity, message)
        VALUES ('$esc_path', '$agent_role', '$finding_type', '$severity', '$esc_msg');
    "
}

# ---------------------------------------------------------------------------
# db_resolve_finding – označí nález jako vyřešený (např. po opravě).
# ---------------------------------------------------------------------------
db_resolve_finding() {
    local finding_id="$1" resolved_by="$2"
    _db_exec "
        UPDATE findings
        SET resolved_at = strftime('%s','now'), resolved_by = '$resolved_by'
        WHERE id = $finding_id;
    "
}

# ---------------------------------------------------------------------------
# db_upsert_file – vloží/aktualizuje záznam v centrálním indexu souborů.
# ---------------------------------------------------------------------------
db_upsert_file() {
    local path="$1" size="$2" mtime="$3" hash="$4" ftype="$5" preview="$6" agent_id="$7"
    local esc_path="${path//\'/\'\'}"
    local esc_preview="${preview//\'/\'\'}"
    _db_exec "
        INSERT INTO files (path, size_bytes, mtime, hash_md5, file_type, content_preview, last_indexed_by)
        VALUES ('$esc_path', $size, $mtime, '$hash', '$ftype', '$esc_preview', '$agent_id')
        ON CONFLICT(path) DO UPDATE SET
            size_bytes = excluded.size_bytes,
            mtime = excluded.mtime,
            hash_md5 = excluded.hash_md5,
            file_type = excluded.file_type,
            content_preview = excluded.content_preview,
            last_seen = strftime('%s','now'),
            last_indexed_by = excluded.last_indexed_by,
            status = 'active';
    "
}

# ---------------------------------------------------------------------------
# db_register_agent – zaregistruje/aktualizuje agenta při startu.
# ---------------------------------------------------------------------------
db_register_agent() {
    local agent_id="$1" role="$2" pid="$3"
    _db_exec "
        INSERT INTO agents (agent_id, role, pid, status)
        VALUES ('$agent_id', '$role', $pid, 'idle')
        ON CONFLICT(agent_id) DO UPDATE SET
            pid = excluded.pid,
            status = 'idle',
            started_at = strftime('%s','now'),
            last_heartbeat = strftime('%s','now');
    "
}

# ---------------------------------------------------------------------------
# db_heartbeat – aktualizuje last_heartbeat a status agenta.
# Použití: db_heartbeat <agent_id> <status> [current_task_id]
# ---------------------------------------------------------------------------
db_heartbeat() {
    local agent_id="$1" status="$2" current_task_id="${3:-NULL}"
    _db_exec "
        UPDATE agents
        SET last_heartbeat = strftime('%s','now'), status = '$status',
            current_task_id = $current_task_id
        WHERE agent_id = '$agent_id';
    "
}

# ---------------------------------------------------------------------------
# db_increment_agent_stat – inkrementuje tasks_completed/tasks_failed.
# Použití: db_increment_agent_stat <agent_id> <completed|failed>
# ---------------------------------------------------------------------------
db_increment_agent_stat() {
    local agent_id="$1" kind="$2"
    local col="tasks_completed"
    [[ "$kind" == "failed" ]] && col="tasks_failed"
    _db_exec "UPDATE agents SET $col = $col + 1 WHERE agent_id = '$agent_id';"
}

# ---------------------------------------------------------------------------
# db_mark_stale_agents_crashed – pro dashboard/orchestrátor: agenty bez
# heartbeatu déle než AGENT_STALE_SECONDS oznaci jako 'crashed'.
# ---------------------------------------------------------------------------
db_mark_stale_agents_crashed() {
    local now; now=$(date +%s)
    local cutoff=$(( now - AGENT_STALE_SECONDS ))
    _db_exec "
        UPDATE agents
        SET status = 'crashed'
        WHERE last_heartbeat < $cutoff AND status NOT IN ('crashed','stopped');
    "
}

# ---------------------------------------------------------------------------
# db_repair_attempt_count – kolik pokusů o opravu proběhlo pro daný soubor
# v posledních N sekundách (pro circuit breaker v Repairer roli).
# ---------------------------------------------------------------------------
db_repair_attempt_count() {
    local file_path="$1" window_seconds="${2:-3600}"
    local esc_path="${file_path//\'/\'\'}"
    local cutoff=$(( $(date +%s) - window_seconds ))
    _db_exec "
        SELECT COUNT(*) FROM repair_attempts
        WHERE file_path = '$esc_path' AND attempted_at >= $cutoff;
    "
}

db_record_repair_attempt() {
    local file_path="$1" outcome="$2"
    local esc_path="${file_path//\'/\'\'}"
    _db_exec "
        INSERT INTO repair_attempts (file_path, outcome) VALUES ('$esc_path', '$outcome');
    "
}
