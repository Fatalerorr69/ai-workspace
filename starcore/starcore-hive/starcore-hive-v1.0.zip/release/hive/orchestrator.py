#!/usr/bin/env python3
# =============================================================================
# STARCORE HIVE – orchestrator.py
# Verze: 1.0
#
# Odpovědnosti:
#   1. Správa životního cyklu agentů (start/stop/restart podle agents.yaml)
#   2. Periodické vkládání scan_dir úkolů do fronty
#   3. Watchdog – detekce crashnutých agentů, automatický restart
#   4. Periodický release osiřelých (claimed-timeout) úkolů
#   5. Periodický librarian_merge trigger
#   6. Migrace starých builder_state souborů při prvním spuštění
#
# Spuštění:
#   python3 orchestrator.py [--hive-dir /root/starcore/hive] [--dry-run]
# =============================================================================

import argparse
import json
import logging
import os
import pathlib
import signal
import sqlite3
import subprocess
import sys
import threading
import time
import shutil
import re
from typing import Optional

# ---------------------------------------------------------------------------
# Konfigurace loggeru
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s][ORCHESTRATOR][%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("orchestrator")


# ---------------------------------------------------------------------------
# Výchozí hodnoty (přepisovatelné přes agents.yaml nebo env)
# ---------------------------------------------------------------------------
DEFAULTS = {
    "scan_interval_seconds": 300,       # jak často vložit scan_dir úkoly
    "watchdog_interval_seconds": 30,    # jak často kontrolovat živost agentů
    "claim_release_interval": 60,       # jak často uvolňovat osiřelé claimy
    "librarian_interval_seconds": 1800, # jak často spustit librarian merge
    "claim_timeout_seconds": 300,       # po kolika sekundách je claim "osiřelý"
    "agent_stale_seconds": 60,          # po kolika sekundách bez heartbeatu = crashed
    "scan_dirs": ["/root/starcore", "/opt"],
    "agents": [
        {"role": "indexer",   "count": 1},
        {"role": "analyzer",  "count": 2},
        {"role": "inspector", "count": 2},
        {"role": "repairer",  "count": 1},
        {"role": "librarian", "count": 1},
        {"role": "watcher",   "count": 1},
    ],
}


# =============================================================================
# DB HELPERS (lehká vrstva nad sqlite3, bez externích závislostí)
# =============================================================================

class HiveDB:
    """Thread-safe SQLite wrapper s WAL mode a busy_timeout."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._local = threading.local()

    def _conn(self) -> sqlite3.Connection:
        """Vrátí per-thread connection (sqlite3 není thread-safe napříč vlákny)."""
        if not hasattr(self._local, "conn") or self._local.conn is None:
            conn = sqlite3.connect(self.db_path, timeout=10)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA busy_timeout=5000")
            conn.execute("PRAGMA foreign_keys=ON")
            self._local.conn = conn
        return self._local.conn

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        return self._conn().execute(sql, params)

    def executemany(self, sql: str, params_list) -> sqlite3.Cursor:
        return self._conn().executemany(sql, params_list)

    def commit(self):
        self._conn().commit()

    def fetchone(self, sql: str, params: tuple = ()) -> Optional[sqlite3.Row]:
        return self.execute(sql, params).fetchone()

    def fetchall(self, sql: str, params: tuple = ()) -> list:
        return self.execute(sql, params).fetchall()

    def add_task(self, task_type: str, target_role: str,
                 payload: dict, priority: int = 5) -> int:
        """Vloží nový úkol do fronty. Vrátí jeho ID."""
        payload_json = json.dumps(payload, ensure_ascii=False)
        cur = self.execute(
            "INSERT INTO tasks (type, target_role, payload_json, priority) "
            "VALUES (?, ?, ?, ?)",
            (task_type, target_role, payload_json, priority),
        )
        self.commit()
        return cur.lastrowid

    def release_expired_claims(self, timeout_seconds: int):
        """Vrátí osiřelé 'claimed' úkoly zpět na 'pending'."""
        cutoff = int(time.time()) - timeout_seconds
        cur = self.execute(
            "UPDATE tasks "
            "SET status='pending', claimed_by=NULL, claimed_at=NULL "
            "WHERE status='claimed' AND claimed_at < ?",
            (cutoff,),
        )
        self.commit()
        released = cur.rowcount
        if released > 0:
            log.info(f"Uvolněno {released} osiřelých úkolů zpět do fronty")
        return released

    def mark_stale_agents_crashed(self, stale_seconds: int):
        """Agenty bez heartbeatu déle než stale_seconds označí jako 'crashed'."""
        cutoff = int(time.time()) - stale_seconds
        cur = self.execute(
            "UPDATE agents SET status='crashed' "
            "WHERE last_heartbeat < ? AND status NOT IN ('crashed','stopped')",
            (cutoff,),
        )
        self.commit()
        if cur.rowcount > 0:
            log.warning(f"Označeno {cur.rowcount} agentů jako 'crashed' (bez heartbeatu)")
        return cur.rowcount

    def get_agent_status(self) -> list:
        return self.fetchall(
            "SELECT agent_id, role, pid, status, last_heartbeat, "
            "tasks_completed, tasks_failed FROM agents ORDER BY role, agent_id"
        )

    def get_task_counts(self) -> dict:
        rows = self.fetchall(
            "SELECT status, COUNT(*) as cnt FROM tasks GROUP BY status"
        )
        return {row["status"]: row["cnt"] for row in rows}

    def get_pending_count_by_role(self) -> dict:
        rows = self.fetchall(
            "SELECT target_role, COUNT(*) as cnt FROM tasks "
            "WHERE status='pending' GROUP BY target_role"
        )
        return {row["target_role"]: row["cnt"] for row in rows}

    def get_finding_summary(self) -> list:
        return self.fetchall(
            "SELECT finding_type, severity, COUNT(*) as cnt "
            "FROM findings WHERE resolved_at IS NULL "
            "GROUP BY finding_type, severity ORDER BY cnt DESC"
        )


# =============================================================================
# SPRÁVA AGENTŮ
# =============================================================================

class AgentProcess:
    """Reprezentuje jeden spuštěný agent worker proces."""

    def __init__(self, agent_id: str, role: str, hive_dir: str,
                 env: dict, dry_run: bool = False):
        self.agent_id = agent_id
        self.role = role
        self.hive_dir = hive_dir
        self.env = env
        self.dry_run = dry_run
        self.process: Optional[subprocess.Popen] = None
        self.started_at: Optional[float] = None

    def start(self):
        worker_script = os.path.join(self.hive_dir, "agents", "agent-worker.sh")
        if not os.path.isfile(worker_script):
            log.error(f"worker skript nenalezen: {worker_script}")
            return False

        cmd = ["bash", worker_script, self.role, self.agent_id]
        if self.dry_run:
            cmd.append("--dry-run")

        log_dir = os.path.join(self.hive_dir, "logs", self.role)
        os.makedirs(log_dir, exist_ok=True)
        log_file = open(os.path.join(log_dir, f"{self.agent_id}.log"), "a")

        try:
            self.process = subprocess.Popen(
                cmd,
                env=self.env,
                stdout=log_file,
                stderr=subprocess.STDOUT,
                # Nový process group, aby SIGINT z terminálu nešel na agenty
                start_new_session=True,
            )
            self.started_at = time.time()
            log.info(f"Agent spuštěn: {self.agent_id} (role={self.role}, PID={self.process.pid})")
            return True
        except Exception as e:
            log.error(f"Nepodařilo se spustit agenta {self.agent_id}: {e}")
            return False

    def is_alive(self) -> bool:
        if self.process is None:
            return False
        return self.process.poll() is None

    def stop(self, timeout: int = 10):
        if self.process and self.is_alive():
            log.info(f"Zastavuji agenta {self.agent_id} (PID={self.process.pid})")
            self.process.terminate()
            try:
                self.process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                log.warning(f"Agent {self.agent_id} neodpověděl na SIGTERM, posílám SIGKILL")
                self.process.kill()

    def returncode(self) -> Optional[int]:
        if self.process:
            return self.process.returncode
        return None


class AgentManager:
    """Spravuje pool agentů podle konfigurace."""

    def __init__(self, hive_dir: str, config: dict, db: HiveDB, dry_run: bool):
        self.hive_dir = hive_dir
        self.config = config
        self.db = db
        self.dry_run = dry_run
        # agent_id → AgentProcess
        self.agents: dict[str, AgentProcess] = {}
        self._lock = threading.Lock()

    def _build_env(self) -> dict:
        env = os.environ.copy()
        env["HIVE_DIR"] = self.hive_dir
        env["DB_PATH"] = os.path.join(self.hive_dir, "registry.db")
        env["SCAN_DIRS"] = ":".join(self.config.get("scan_dirs", DEFAULTS["scan_dirs"]))
        env["ALLOWED_REPAIR_ROOTS"] = ":".join(
            self.config.get("scan_dirs", DEFAULTS["scan_dirs"])
        )
        env["CLAIM_TIMEOUT_SECONDS"] = str(
            self.config.get("claim_timeout_seconds", DEFAULTS["claim_timeout_seconds"])
        )
        env["AGENT_STALE_SECONDS"] = str(
            self.config.get("agent_stale_seconds", DEFAULTS["agent_stale_seconds"])
        )
        env["HEARTBEAT_INTERVAL"] = "15"
        env["TASK_SLEEP_IDLE"] = "3"
        return env

    def start_all(self):
        """Spustí všechny agenty podle konfigurace."""
        env = self._build_env()
        for agent_def in self.config.get("agents", DEFAULTS["agents"]):
            role = agent_def["role"]
            count = agent_def.get("count", 1)
            for i in range(1, count + 1):
                agent_id = f"{role}-{i}"
                self._start_agent(agent_id, role, env)

    def _start_agent(self, agent_id: str, role: str, env: dict):
        with self._lock:
            agent = AgentProcess(agent_id, role, self.hive_dir, env, self.dry_run)
            if agent.start():
                self.agents[agent_id] = agent

    def stop_all(self):
        """Zastaví všechny agenty."""
        with self._lock:
            for agent in self.agents.values():
                agent.stop()
            self.agents.clear()

    def watchdog_tick(self):
        """
        Projde všechny agenty, detekuje páды a restartuje je.
        Volá se periodicky z orchestrátorova hlavního vlákna.
        """
        env = self._build_env()
        with self._lock:
            for agent_id, agent in list(self.agents.items()):
                if not agent.is_alive():
                    rc = agent.returncode()
                    log.warning(
                        f"Agent {agent_id} neběží (exitcode={rc}), restartuji..."
                    )
                    new_agent = AgentProcess(
                        agent_id, agent.role, self.hive_dir, env, self.dry_run
                    )
                    if new_agent.start():
                        self.agents[agent_id] = new_agent
                    else:
                        log.error(f"Restart agenta {agent_id} selhal!")

    def get_status(self) -> list[dict]:
        with self._lock:
            return [
                {
                    "agent_id": aid,
                    "role": a.role,
                    "pid": a.process.pid if a.process else None,
                    "alive": a.is_alive(),
                    "started_at": a.started_at,
                }
                for aid, a in self.agents.items()
            ]


# =============================================================================
# ORCHESTRÁTOR
# =============================================================================

class Orchestrator:
    def __init__(self, hive_dir: str, config: dict, dry_run: bool = False):
        self.hive_dir = hive_dir
        self.config = config
        self.dry_run = dry_run
        self.running = False

        db_path = os.path.join(hive_dir, "registry.db")
        self.db = HiveDB(db_path)
        self.agent_manager = AgentManager(hive_dir, config, self.db, dry_run)

        # Timestamps posledních periodických akcí
        self._last_scan_seed = 0.0
        self._last_watchdog = 0.0
        self._last_claim_release = 0.0
        self._last_librarian = 0.0
        self._last_stats_log = 0.0

    # -------------------------------------------------------------------------
    # Migrace ze starých builder_state souborů
    # -------------------------------------------------------------------------
    def migrate_legacy(self):
        """
        Pokud existují staré .builder_state soubory z původních 4 skriptů,
        přesune je do archive/ a zaznamená historii do DB jako info finding.
        """
        base_dir = pathlib.Path(self.hive_dir).parent
        state_patterns = [
            base_dir / "bin" / "optimized" / ".builder_state",
            base_dir / "bin" / "optimized-lite" / ".builder_state",
        ]
        archive_dir = base_dir / "archive" / "legacy-builder"
        migrated = 0

        for state_file in state_patterns:
            if state_file.exists():
                archive_dir.mkdir(parents=True, exist_ok=True)
                dest = archive_dir / f"{state_file.parent.name}-builder_state"
                shutil.move(str(state_file), str(dest))
                log.info(f"Migrováno: {state_file} → {dest}")
                # Záznam do findings jako informace (ne chyba)
                try:
                    self.db.execute(
                        "INSERT INTO findings (file_path, agent_role, finding_type, severity, message) "
                        "VALUES (?, 'orchestrator', 'needs_manual_review', 'info', ?)",
                        (str(dest), f"Migrovaný legacy state ze {state_file}"),
                    )
                    self.db.commit()
                except Exception:
                    pass
                migrated += 1

        # Archivovat staré skripty (přesunout, ne smazat)
        old_scripts = [
            base_dir / "starcore-auto-builder-v3_0.sh",
            base_dir / "starcore-auto-builder-lite.sh",
            base_dir / "starcore-auto-builder-final.sh",
            base_dir / "starcore-auto-builder-deep.sh",
        ]
        for script in old_scripts:
            if script.exists():
                archive_dir.mkdir(parents=True, exist_ok=True)
                dest = archive_dir / script.name
                shutil.move(str(script), str(dest))
                log.info(f"Archivován starý skript: {script.name}")
                migrated += 1

        if migrated > 0:
            log.info(f"Migrace dokončena: {migrated} souborů přesunuto do {archive_dir}")
        else:
            log.info("Migrace: žádné legacy soubory nenalezeny")

    # -------------------------------------------------------------------------
    # Periodické akce
    # -------------------------------------------------------------------------
    def _seed_scan_tasks(self):
        """Vloží scan_dir úkol pro každý konfigurovaný adresář."""
        scan_dirs = self.config.get("scan_dirs", DEFAULTS["scan_dirs"])
        seeded = 0
        for d in scan_dirs:
            if os.path.isdir(d):
                self.db.add_task("scan_dir", "indexer", {"path": d}, priority=5)
                seeded += 1
        if seeded:
            log.info(f"Vloženo {seeded} scan_dir úkolů")
        # Watcher dostane signál přes svůj vlastní task
        self.db.add_task("watch_dirs", "watcher", {}, priority=8)

    def _trigger_librarian(self):
        """Vloží librarian_merge úkol."""
        self.db.add_task("librarian_merge", "librarian", {}, priority=8)
        log.info("Vložen librarian_merge úkol")

    def _log_stats(self):
        """Vypíše do logu aktuální statistiky fronty a agentů."""
        task_counts = self.db.get_task_counts()
        pending_by_role = self.db.get_pending_count_by_role()
        agents = self.db.get_agent_status()

        log.info("─── Statistiky ───────────────────────────────")
        log.info(f"  Úkoly: {dict(task_counts)}")
        log.info(f"  Pending dle role: {dict(pending_by_role)}")
        for a in agents:
            hb_age = int(time.time()) - (a["last_heartbeat"] or 0)
            log.info(
                f"  Agent {a['agent_id']:20s} status={a['status']:10s} "
                f"done={a['tasks_completed']:4d} failed={a['tasks_failed']:3d} "
                f"heartbeat_před={hb_age}s"
            )
        log.info("──────────────────────────────────────────────")

    # -------------------------------------------------------------------------
    # Hlavní smyčka
    # -------------------------------------------------------------------------
    def run(self):
        self.running = True
        log.info("═══════════════════════════════════════════════════")
        log.info("STARCORE HIVE Orchestrator spouštím")
        log.info(f"  HIVE_DIR : {self.hive_dir}")
        log.info(f"  DB       : {os.path.join(self.hive_dir, 'registry.db')}")
        log.info(f"  DRY-RUN  : {self.dry_run}")
        log.info("═══════════════════════════════════════════════════")

        # Migrace legacy souborů
        self.migrate_legacy()

        # Seed prvního skenu okamžitě
        self._seed_scan_tasks()
        self._last_scan_seed = time.time()

        # Spuštění agentů
        self.agent_manager.start_all()

        # Hlavní smyčka orchestrátoru (tick každých 5 sekund)
        while self.running:
            now = time.time()
            cfg = self.config

            # Watchdog agentů
            if now - self._last_watchdog >= cfg.get(
                "watchdog_interval_seconds", DEFAULTS["watchdog_interval_seconds"]
            ):
                self.agent_manager.watchdog_tick()
                self.db.mark_stale_agents_crashed(
                    cfg.get("agent_stale_seconds", DEFAULTS["agent_stale_seconds"])
                )
                self._last_watchdog = now

            # Uvolnění osiřelých claimů
            if now - self._last_claim_release >= cfg.get(
                "claim_release_interval", DEFAULTS["claim_release_interval"]
            ):
                self.db.release_expired_claims(
                    cfg.get("claim_timeout_seconds", DEFAULTS["claim_timeout_seconds"])
                )
                self._last_claim_release = now

            # Periodický scan
            if now - self._last_scan_seed >= cfg.get(
                "scan_interval_seconds", DEFAULTS["scan_interval_seconds"]
            ):
                self._seed_scan_tasks()
                self._last_scan_seed = now

            # Periodický librarian merge
            if now - self._last_librarian >= cfg.get(
                "librarian_interval_seconds", DEFAULTS["librarian_interval_seconds"]
            ):
                self._trigger_librarian()
                self._last_librarian = now

            # Statistiky každých 60 sekund
            if now - self._last_stats_log >= 60:
                self._log_stats()
                self._last_stats_log = now

            time.sleep(5)

        # Ukončení
        log.info("Orchestrátor se zastavuje, ukončuji agenty...")
        self.agent_manager.stop_all()
        log.info("Orchestrátor ukončen.")

    def stop(self):
        self.running = False


# =============================================================================
# NAČTENÍ KONFIGURACE (agents.yaml / agents.json)
# =============================================================================

def load_config(hive_dir: str) -> dict:
    """
    Načte konfiguraci agentů. Priorita:
      1. hive/config/agents.yaml (pokud python-yaml dostupný)
      2. hive/config/agents.json
      3. Výchozí hodnoty z DEFAULTS
    """
    config_dir = os.path.join(hive_dir, "config")
    os.makedirs(config_dir, exist_ok=True)

    # Zkusíme YAML
    yaml_path = os.path.join(config_dir, "agents.yaml")
    if os.path.isfile(yaml_path):
        try:
            import yaml
            with open(yaml_path) as f:
                cfg = yaml.safe_load(f)
            log.info(f"Konfigurace načtena z {yaml_path}")
            return {**DEFAULTS, **cfg}
        except ImportError:
            log.warning("python-yaml nedostupný, zkouším agents.json")
        except Exception as e:
            log.warning(f"Chyba při čtení {yaml_path}: {e}")

    # Zkusíme JSON
    json_path = os.path.join(config_dir, "agents.json")
    if os.path.isfile(json_path):
        try:
            with open(json_path) as f:
                cfg = json.load(f)
            log.info(f"Konfigurace načtena z {json_path}")
            return {**DEFAULTS, **cfg}
        except Exception as e:
            log.warning(f"Chyba při čtení {json_path}: {e}, používám výchozí hodnoty")

    # Zapíšeme výchozí konfiguraci jako JSON pro příští použití
    try:
        with open(json_path, "w") as f:
            json.dump(DEFAULTS, f, indent=2, ensure_ascii=False)
        log.info(f"Výchozí konfigurace zapsána do {json_path}")
    except Exception:
        pass

    log.info("Používám výchozí konfiguraci")
    return DEFAULTS.copy()


# =============================================================================
# INICIALIZACE DB (schema.sql)
# =============================================================================

def ensure_db(hive_dir: str) -> bool:
    db_path = os.path.join(hive_dir, "registry.db")
    schema_path = os.path.join(hive_dir, "schema.sql")

    if not os.path.isfile(schema_path):
        log.error(f"schema.sql nenalezen: {schema_path}")
        return False

    try:
        conn = sqlite3.connect(db_path, timeout=10)
        with open(schema_path) as f:
            conn.executescript(f.read())
        conn.commit()
        conn.close()
        log.info(f"DB inicializována: {db_path}")
        return True
    except Exception as e:
        log.error(f"Chyba při inicializaci DB: {e}")
        return False


# =============================================================================
# NASTAVENÍ LOGOVÁNÍ DO SOUBORU
# =============================================================================

def setup_file_logging(hive_dir: str):
    log_dir = os.path.join(hive_dir, "logs", "orchestrator")
    os.makedirs(log_dir, exist_ok=True)
    from datetime import datetime
    log_file = os.path.join(log_dir, f"orchestrator-{datetime.now():%Y%m%d-%H%M%S}.log")
    fh = logging.FileHandler(log_file)
    fh.setFormatter(logging.Formatter(
        "[%(asctime)s][ORCHESTRATOR][%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    ))
    logging.getLogger().addHandler(fh)
    log.info(f"Log: {log_file}")


# =============================================================================
# VSTUPNÍ BOD
# =============================================================================

def main():
    parser = argparse.ArgumentParser(description="STARCORE HIVE Orchestrator")
    parser.add_argument(
        "--hive-dir", default="/root/starcore/hive",
        help="Cesta ke kořeni hive adresáře (výchozí: /root/starcore/hive)"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Dry-run: agenti Repairer a Librarian pouze hlásí, nezapisují"
    )
    parser.add_argument(
        "--migrate-only", action="store_true",
        help="Pouze migruje legacy soubory a skončí (nespouští agenty)"
    )
    args = parser.parse_args()

    hive_dir = os.path.abspath(args.hive_dir)
    os.makedirs(hive_dir, exist_ok=True)

    setup_file_logging(hive_dir)

    # Ověření a inicializace DB
    if not ensure_db(hive_dir):
        sys.exit(1)

    # Načtení konfigurace
    config = load_config(hive_dir)

    # Nastavení scan_dirs z env pokud je k dispozici
    if "SCAN_DIRS" in os.environ:
        config["scan_dirs"] = os.environ["SCAN_DIRS"].split(":")

    # Vytvoření orchestrátoru
    orch = Orchestrator(hive_dir=hive_dir, config=config, dry_run=args.dry_run)

    if args.migrate_only:
        orch.migrate_legacy()
        log.info("--migrate-only dokončeno, ukončuji")
        return

    # Signal handlery pro čisté ukončení
    def _sig_handler(signum, frame):
        log.info(f"Přijat signál {signum}, zastavuji...")
        orch.stop()

    signal.signal(signal.SIGINT, _sig_handler)
    signal.signal(signal.SIGTERM, _sig_handler)

    orch.run()


if __name__ == "__main__":
    main()
