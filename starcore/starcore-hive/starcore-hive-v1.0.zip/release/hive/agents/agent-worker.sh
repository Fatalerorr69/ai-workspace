#!/bin/bash
# ============================================================================
# STARCORE HIVE – agent-worker.sh
# Generický worker pro všechny role. Role se předává jako první argument.
#
# Použití:
#   agent-worker.sh <role> <agent_id> [--dry-run]
#
# Role: indexer | analyzer | inspector | repairer | librarian | watcher
#
# Proměnné prostředí (musí být nastaveny před spuštěním, typicky systemd):
#   HIVE_DIR     – absolutní cesta ke kořeni hive (/root/starcore/hive)
#   SCAN_DIRS    – dvojtečkou oddělené adresáře ke skenování
#   DB_PATH      – cesta k registry.db (výchozí: $HIVE_DIR/registry.db)
# ============================================================================

set -uo pipefail

# ---------------------------------------------------------------------------
# Argumenty a konfigurace
# ---------------------------------------------------------------------------
AGENT_ROLE="${1:?Použití: $0 <role> <agent_id> [--dry-run]}"
AGENT_ID="${2:?Použití: $0 <role> <agent_id> [--dry-run]}"
DRY_RUN=0
[[ "${3:-}" == "--dry-run" ]] && DRY_RUN=1

# Hive kořen – buď z env, nebo odvodíme z umístění tohoto skriptu
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HIVE_DIR="${HIVE_DIR:-$(dirname "$SCRIPT_DIR")}"
DB_PATH="${DB_PATH:-$HIVE_DIR/registry.db}"
LOG_DIR="${LOG_DIR:-$HIVE_DIR/logs/$AGENT_ROLE}"

# Adresáře ke skenování (Indexer/Watcher)
IFS=':' read -ra SCAN_DIRS_ARR <<< "${SCAN_DIRS:-/root/starcore:/opt}"

# Bezpečné kořeny pro auto-repair (Repairer)
IFS=':' read -ra ALLOWED_REPAIR_ROOTS <<< "${ALLOWED_REPAIR_ROOTS:-/root/starcore:/opt}"
export ALLOWED_REPAIR_ROOTS

# Heartbeat interval a claim timeout
HEARTBEAT_INTERVAL="${HEARTBEAT_INTERVAL:-15}"
TASK_SLEEP_IDLE="${TASK_SLEEP_IDLE:-3}"   # jak dlouho čekat, pokud je fronta prázdná

# ---------------------------------------------------------------------------
# Source sdílených knihoven
# ---------------------------------------------------------------------------
source "$HIVE_DIR/lib/db.sh"
source "$HIVE_DIR/lib/common.sh"

# ---------------------------------------------------------------------------
# Inicializace
# ---------------------------------------------------------------------------
mkdir -p "$LOG_DIR"

log_info "═══════════════════════════════════════════"
log_info "STARCORE HIVE Agent starting"
log_info "  Role    : $AGENT_ROLE"
log_info "  ID      : $AGENT_ID"
log_info "  PID     : $$"
log_info "  DB      : $DB_PATH"
log_info "  DRY-RUN : $DRY_RUN"
log_info "═══════════════════════════════════════════"

# Ověření, že DB existuje a je dostupná
db_check_available || { log_error "DB není dostupná, ukončuji"; exit 1; }

# Zaregistrovat se do DB
db_register_agent "$AGENT_ID" "$AGENT_ROLE" "$$"

# Signal handler
CURRENT_TASK_ID="NULL"
CURRENT_STATUS="idle"
trap agent_cleanup SIGINT SIGTERM

# Spustit heartbeat smyčku na pozadí
start_heartbeat_loop "$HEARTBEAT_INTERVAL"

# ============================================================================
# ROLE IMPLEMENTACE
# ============================================================================

# ---------------------------------------------------------------------------
# INDEXER: skenuje adresáře, přidává nové/změněné soubory do DB
# ---------------------------------------------------------------------------
run_indexer() {
    local payload_json="$1"

    # Načteme cíl ze scanu z payload, nebo skenujeme všechny SCAN_DIRS
    local target_dir=""
    if [[ -n "$payload_json" ]]; then
        target_dir=$(echo "$payload_json" | grep -oP '(?<="path":")[^"]+')
    fi

    local dirs_to_scan=()
    if [[ -n "$target_dir" && -d "$target_dir" ]]; then
        dirs_to_scan=("$target_dir")
    else
        dirs_to_scan=("${SCAN_DIRS_ARR[@]}")
    fi

    local total_new=0 total_updated=0 total_skipped=0

    for scan_dir in "${dirs_to_scan[@]}"; do
        [[ -d "$scan_dir" ]] || { log_warn "Indexer: $scan_dir neexistuje, přeskakuji"; continue; }
        log_info "Indexer: skenuju $scan_dir"

        while IFS= read -r fpath; do
            [[ -f "$fpath" ]] || continue

            # Přírůstkový sken: načteme mtime a size ze souboru
            local fmtime fsize
            fmtime=$(stat -c%Y "$fpath" 2>/dev/null || echo 0)
            fsize=$(stat -c%s "$fpath" 2>/dev/null || echo 0)

            # Zjistíme, jestli soubor v DB existuje a jestli je aktuální
            local db_mtime
            db_mtime=$(sqlite3 -batch "$DB_PATH" \
                "SELECT mtime FROM files WHERE path='${fpath//\'/\'\'}' AND status='active';" 2>/dev/null)

            if [[ "$db_mtime" == "$fmtime" ]]; then
                (( total_skipped++ )) || true
                continue
            fi

            # Nový nebo změněný soubor – vložíme do DB, vygenerujeme analyze úkol
            local ftype; ftype=$(get_file_type "$fpath")
            local preview; preview=$(head -c 200 "$fpath" 2>/dev/null | tr -d '\0\n' | head -c 200)

            db_upsert_file "$fpath" "$fsize" "$fmtime" "" "$ftype" "$preview" "$AGENT_ID"

            if [[ -z "$db_mtime" ]]; then
                (( total_new++ )) || true
            else
                (( total_updated++ )) || true
            fi

            # Generovat navazující úkoly pro nové/změněné soubory
            local escaped_path="${fpath//\"/\\\"}"
            db_add_task "analyze_file" "analyzer" \
                "{\"path\":\"$escaped_path\"}" 5 > /dev/null
            db_add_task "inspect_file" "inspector" \
                "{\"path\":\"$escaped_path\"}" 5 > /dev/null

        done < <(find "${scan_dir}" -type f \( \
            -name "*.sh" -o -name "*.py" -o -name "*.js" -o \
            -name "*.yaml" -o -name "*.yml" -o -name "*.json" -o \
            -name "*.md" -o -name "*.txt" -o -name "*.conf" -o \
            -name "*.service" -o -name "*.cron" \
        \) 2>/dev/null)
    done

    log_ok "Indexer hotov: nových=$total_new, aktualizovaných=$total_updated, přeskočených=$total_skipped"
}

# ---------------------------------------------------------------------------
# ANALYZER: extrahuje úplná metadata + hash pro konkrétní soubor
# ---------------------------------------------------------------------------
run_analyzer() {
    local payload_json="$1"
    local fpath; fpath=$(echo "$payload_json" | grep -oP '(?<="path":")[^"]+')

    [[ -n "$fpath" && -f "$fpath" ]] || {
        log_warn "Analyzer: soubor neexistuje: $fpath"
        return 1
    }

    log_info "Analyzer: zpracovávám $fpath"

    local meta_output
    meta_output=$(extract_file_metadata "$fpath")

    local size mtime hash ftype preview
    while IFS='=' read -r key val; do
        case "$key" in
            size)     size="$val" ;;
            mtime)    mtime="$val" ;;
            hash)     hash="$val" ;;
            file_type) ftype="$val" ;;
            preview)  preview="$val" ;;
        esac
    done <<< "$meta_output"

    db_upsert_file "$fpath" "${size:-0}" "${mtime:-0}" \
        "${hash:-}" "${ftype:-other}" "${preview:-}" "$AGENT_ID"

    # Detekce duplicit podle hash
    if [[ -n "${hash:-}" && "$hash" != "too_large" ]]; then
        local esc_path="${fpath//\'/\'\'}"
        local esc_hash="${hash//\'/\'\'}"
        local dup_path
        dup_path=$(sqlite3 -batch "$DB_PATH" \
            "SELECT path FROM files WHERE hash_md5='$esc_hash' AND path != '$esc_path' AND status='active' LIMIT 1;" 2>/dev/null)
        if [[ -n "$dup_path" ]]; then
            db_record_finding "$fpath" "$AGENT_ID" "duplicate" "info" \
                "Duplicitní obsah s: $dup_path (hash: $hash)"
            log_info "Analyzer: nalezen duplikát $fpath ↔ $dup_path"
        fi
    fi

    log_ok "Analyzer: $fpath hotov (${size} B, $ftype, hash: ${hash:0:8}...)"
}

# ---------------------------------------------------------------------------
# INSPECTOR: syntax + bezpečnostní vzory + závislosti
# ---------------------------------------------------------------------------
run_inspector() {
    local payload_json="$1"
    local fpath; fpath=$(echo "$payload_json" | grep -oP '(?<="path":")[^"]+')

    [[ -n "$fpath" && -f "$fpath" ]] || {
        log_warn "Inspector: soubor neexistuje: $fpath"
        return 1
    }

    log_info "Inspector: inspektuji $fpath"
    local issues_found=0

    # Syntax check
    check_syntax "$fpath"
    local syntax_rc=$?
    if [[ $syntax_rc -eq 1 ]]; then
        db_record_finding "$fpath" "$AGENT_ID" "syntax_error" "auto_fixable" \
            "Syntaktická chyba – viz bash -n / py_compile / node -c"
        log_warn "Inspector: syntax error v $fpath"
        (( issues_found++ )) || true

        # Vygenerovat repair task pro auto-fixable soubory (.sh)
        if [[ "$fpath" == *.sh ]]; then
            local escaped="${fpath//\"/\\\"}"
            db_add_task "repair_file" "repairer" "{\"path\":\"$escaped\"}" 3 > /dev/null
        fi
    fi

    # Bezpečnostní vzory
    local sec_issues
    sec_issues=$(check_security_patterns "$fpath")
    if [[ -n "$sec_issues" ]]; then
        while IFS= read -r issue; do
            [[ -z "$issue" ]] && continue
            db_record_finding "$fpath" "$AGENT_ID" "security_warning" "warning" "$issue"
            (( issues_found++ )) || true
        done <<< "$sec_issues"
        log_warn "Inspector: $fpath – $(echo "$sec_issues" | wc -l) bezpečnostních varování"
    fi

    # Závislosti
    local dep_issues
    dep_issues=$(check_dependencies "$fpath")
    if [[ -n "$dep_issues" ]]; then
        while IFS= read -r dep; do
            [[ -z "$dep" ]] && continue
            db_record_finding "$fpath" "$AGENT_ID" "missing_dep" "warning" "$dep"
            (( issues_found++ )) || true
        done <<< "$dep_issues"
    fi

    if [[ $issues_found -eq 0 ]]; then
        log_ok "Inspector: $fpath – žádné problémy"
    else
        log_warn "Inspector: $fpath – celkem $issues_found nálezů"
    fi
}

# ---------------------------------------------------------------------------
# REPAIRER: auto-oprava souborů označených Inspectorem
# ---------------------------------------------------------------------------
run_repairer() {
    local payload_json="$1"
    local fpath; fpath=$(echo "$payload_json" | grep -oP '(?<="path":")[^"]+')

    [[ -n "$fpath" && -f "$fpath" ]] || {
        log_warn "Repairer: soubor neexistuje: $fpath"
        return 1
    }

    # Circuit breaker – příliš mnoho pokusů na tento soubor
    if ! circuit_breaker_check "$fpath"; then
        db_record_finding "$fpath" "$AGENT_ID" "needs_manual_review" "error" \
            "Circuit breaker aktivní – $CIRCUIT_BREAKER_MAX oprav za ${CIRCUIT_BREAKER_WINDOW}s překročeno"
        return 1
    fi

    log_info "Repairer: opravuji $fpath (dry-run=$DRY_RUN)"
    db_record_repair_attempt "$fpath" "attempted"

    auto_repair_file "$fpath" "$DRY_RUN"
    local repair_rc=$?

    case $repair_rc in
        0)
            db_record_repair_attempt "$fpath" "repaired"
            # Označit příslušné syntax_error findingy jako vyřešené
            local esc_path="${fpath//\'/\'\'}"
            local finding_ids
            finding_ids=$(sqlite3 -batch "$DB_PATH" \
                "SELECT id FROM findings WHERE file_path='$esc_path' AND finding_type IN ('syntax_error') AND resolved_at IS NULL;" 2>/dev/null)
            while IFS= read -r fid; do
                [[ -n "$fid" ]] && db_resolve_finding "$fid" "$AGENT_ID"
            done <<< "$finding_ids"

            # Znovu inspekci po opravě
            local escaped="${fpath//\"/\\\"}"
            db_add_task "inspect_file" "inspector" "{\"path\":\"$escaped\",\"post_repair\":true}" 4 > /dev/null
            ;;
        1)
            db_record_repair_attempt "$fpath" "no_change"
            log_info "Repairer: $fpath – nic k opravě"
            ;;
        2)
            db_record_repair_attempt "$fpath" "failed"
            log_warn "Repairer: $fpath – oprava selhala (nedostatečná práva nebo mimo safe roots)"
            ;;
    esac
}

# ---------------------------------------------------------------------------
# LIBRARIAN: slučuje skripty do centrální knihovny (bin/optimized)
# ---------------------------------------------------------------------------
run_librarian() {
    local payload_json="${1:-{}}"
    log_info "Librarian: spouštím merge a katalogizaci"

    local lib_dir; lib_dir="$(dirname "$HIVE_DIR")/bin/optimized"
    mkdir -p "$lib_dir"

    local categories=(fix diagnostic backup ai monitoring deploy other)
    for cat in "${categories[@]}"; do
        local cat_script="$lib_dir/starcore-${cat}-all.sh"

        # Soubory v DB patřící do kategorie (název nebo preview obsahuje klíčové slovo)
        local file_list
        file_list=$(sqlite3 -batch "$DB_PATH" \
            "SELECT path FROM files
             WHERE status='active'
               AND file_type='sh'
               AND (path LIKE '%$cat%' OR content_preview LIKE '%$cat%')
             ORDER BY last_seen DESC;" 2>/dev/null)

        local count; count=$(echo "$file_list" | grep -c . || true)
        [[ $count -eq 0 ]] && continue

        if [[ "$DRY_RUN" -eq 1 ]]; then
            log_info "Librarian [DRY-RUN]: kategorie '$cat' – $count souborů → $cat_script"
            continue
        fi

        {
            echo "#!/bin/bash"
            echo "# STARCORE HIVE Librarian – kategorie: $cat"
            echo "# Vygenerováno: $(date)"
            echo "# Zdrojů: $count"
            echo "set -uo pipefail"
            echo "log() { echo \"[\$(date)] \$*\"; }"
            echo ""
            echo "case \"\${1:-}\" in"
            echo "  list)"
            while IFS= read -r src; do
                [[ -n "$src" && -f "$src" ]] || continue
                echo "    echo '  - $(basename "$src")'"
            done <<< "$file_list"
            echo "    ;;"
            echo "  run-all)"
            echo "    log 'Spouštím kategorii: $cat'"
            while IFS= read -r src; do
                [[ -n "$src" && -f "$src" ]] || continue
                echo "    bash \"$src\" || log 'WARN: $(basename "$src") selhalo'"
            done <<< "$file_list"
            echo "    ;;"
            echo "  *) echo 'Použití: \$0 [list|run-all]' ;;"
            echo "esac"
        } > "$cat_script"
        chmod +x "$cat_script"

        if bash -n "$cat_script" 2>/dev/null; then
            # Uložit do library tabulky
            local esc_script="${cat_script//\'/\'\'}"
            local esc_sources; esc_sources=$(echo "$file_list" | python3 -c \
                "import sys, json; print(json.dumps(sys.stdin.read().strip().splitlines()))" 2>/dev/null || echo "[]")
            local checksum; checksum=$(md5sum "$cat_script" | cut -d' ' -f1)
            sqlite3 -batch "$DB_PATH" "
                INSERT INTO library (script_path, category, source_files_json, checksum)
                VALUES ('$esc_script', '$cat', '${esc_sources//\'/\'\'}', '$checksum')
                ON CONFLICT(script_path) DO UPDATE SET
                    source_files_json=excluded.source_files_json,
                    checksum=excluded.checksum,
                    version=version+1,
                    updated_at=strftime('%s','now');
            " 2>/dev/null
            log_ok "Librarian: $cat_script (${count} zdrojů)"
        else
            log_warn "Librarian: syntax error v $cat_script, odstraňuji"
            rm -f "$cat_script"
        fi
    done
    log_ok "Librarian: merge dokončen"
}

# ---------------------------------------------------------------------------
# WATCHER: hlídá změny v adresářích, vkládá scan_dir úkoly
# ---------------------------------------------------------------------------
run_watcher() {
    log_info "Watcher: spouštím monitoring adresářů: ${SCAN_DIRS_ARR[*]}"

    # Pokud je k dispozici inotifywait, použijeme ho pro okamžitou reakci
    if command -v inotifywait &>/dev/null; then
        log_info "Watcher: použiji inotifywait (realtime)"
        # inotifywait se spouští s --monitor -- neblokuje smyčku, jen jednou
        # zaznamená první událost za batchovací interval
        local events
        events=$(inotifywait -r -e create,modify,delete,moved_to \
            --format '%w%f %e' \
            --quiet \
            --timeout 60 \
            "${SCAN_DIRS_ARR[@]}" 2>/dev/null | head -20 || true)

        if [[ -n "$events" ]]; then
            log_info "Watcher: detekce změn, spouštím rescan"
            while IFS= read -r evt_line; do
                [[ -z "$evt_line" ]] && continue
                local evt_path; evt_path=$(echo "$evt_line" | cut -d' ' -f1)
                local parent_dir; parent_dir=$(dirname "$evt_path")
                local escaped="${parent_dir//\"/\\\"}"
                db_add_task "scan_dir" "indexer" "{\"path\":\"$escaped\"}" 2 > /dev/null
                log_debug "Watcher: změna v $parent_dir → vložen scan_dir úkol"
            done <<< "$events"
        fi
    else
        # Fallback: mtime-based sken celých adresářů každý cyklus
        log_info "Watcher: inotifywait nedostupný, používám mtime-diff fallback"
        for dir in "${SCAN_DIRS_ARR[@]}"; do
            [[ -d "$dir" ]] || continue
            local escaped="${dir//\"/\\\"}"
            db_add_task "scan_dir" "indexer" "{\"path\":\"$escaped\"}" 5 > /dev/null
        done
        # Watcher počká déle před dalším cyklem (interval určuje orchestrátor
        # prostřednictvím frekvence zadávání Watcher úkolů do fronty)
        sleep 30
    fi
}

# ============================================================================
# HLAVNÍ SMYČKA
# ============================================================================
log_info "Vstupuji do hlavní smyčky (role: $AGENT_ROLE)"
CURRENT_STATUS="idle"
db_heartbeat "$AGENT_ID" "idle" "NULL"

CONSECUTIVE_EMPTY=0

while true; do
    CURRENT_STATUS="idle"

    # Vyzvednutí úkolu z fronty dle role
    CLAIMED=$(db_claim_task "$AGENT_ROLE" "$AGENT_ID")

    if [[ -z "$CLAIMED" ]]; then
        # Fronta prázdná – čekáme s exponenciálním backoffem (max 30s)
        (( CONSECUTIVE_EMPTY++ )) || true
        wait_time=$(( TASK_SLEEP_IDLE * CONSECUTIVE_EMPTY ))
        [[ $wait_time -gt 30 ]] && wait_time=30
        sleep "$wait_time"
        continue
    fi

    CONSECUTIVE_EMPTY=0
    CURRENT_TASK_ID=$(echo "$CLAIMED" | cut -f1)
    task_type=$(echo "$CLAIMED" | cut -f2)
    payload=$(echo "$CLAIMED" | cut -f3)

    CURRENT_STATUS="working"
    db_heartbeat "$AGENT_ID" "working" "$CURRENT_TASK_ID"
    log_info "Převzal úkol #$CURRENT_TASK_ID (typ: $task_type)"

    # Dispatch na příslušnou role-funkci
    task_ok=0
    case "$AGENT_ROLE" in
        indexer)
            run_indexer "$payload" && task_ok=1 || task_ok=0 ;;
        analyzer)
            run_analyzer "$payload" && task_ok=1 || task_ok=0 ;;
        inspector)
            run_inspector "$payload" && task_ok=1 || task_ok=0 ;;
        repairer)
            run_repairer "$payload" && task_ok=1 || task_ok=0 ;;
        librarian)
            run_librarian "$payload" && task_ok=1 || task_ok=0 ;;
        watcher)
            run_watcher && task_ok=1 || task_ok=0 ;;
        *)
            log_error "Neznámá role: $AGENT_ROLE"
            task_ok=0 ;;
    esac

    if [[ $task_ok -eq 1 ]]; then
        db_complete_task "$CURRENT_TASK_ID"
        db_increment_agent_stat "$AGENT_ID" "completed"
    else
        db_fail_task "$CURRENT_TASK_ID" "Role $AGENT_ROLE: zpracování selhalo"
        db_increment_agent_stat "$AGENT_ID" "failed"
    fi

    CURRENT_TASK_ID="NULL"
    CURRENT_STATUS="idle"
    db_heartbeat "$AGENT_ID" "idle" "NULL"
done
