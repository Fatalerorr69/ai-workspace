#!/usr/bin/env python3
# =============================================================================
# STARCORE HIVE – dashboard_http.py
# HTTP dashboard server – JSON API + HTML rozhraní s live grafem a ovládáním.
#
# Porty:
#   HTTP_PORT (výchozí 7979)
#
# Endpointy:
#   GET  /                   → HTML dashboard
#   GET  /api/status         → JSON: kompletní přehled (agenti, úkoly, findings)
#   GET  /api/agents         → JSON: seznam agentů
#   GET  /api/tasks          → JSON: souhrn front
#   GET  /api/findings       → JSON: nezvyřešené findings (max 200)
#   GET  /api/files          → JSON: posledních 50 indexovaných souborů
#   GET  /api/library        → JSON: knihovna skriptů
#   POST /api/agent/restart  → Požadavek na restart agenta (body: {"agent_id":"..."})
#   POST /api/task/add       → Přidá scan_dir úkol (body: {"path":"..."})
# =============================================================================

import argparse
import json
import logging
import os
import signal
import sqlite3
import sys
import time
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from datetime import datetime
from urllib.parse import urlparse, parse_qs
from pathlib import Path

log = logging.getLogger("dashboard_http")

# =============================================================================
# DB HELPERS (kopie z orchestrátoru, záměrně – dashboard je nezávislý)
# =============================================================================

class HiveDB:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._local = threading.local()

    def _conn(self):
        if not hasattr(self._local, "conn") or self._local.conn is None:
            conn = sqlite3.connect(self.db_path, timeout=5)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA busy_timeout=3000")
            conn.execute("PRAGMA query_only=ON")   # dashboard POUZE ČTEUI
            self._local.conn = conn
        return self._local.conn

    def _conn_rw(self):
        """Zapisovatelné spojení (pouze pro /api/task/add a /api/agent/restart)."""
        conn = sqlite3.connect(self.db_path, timeout=5)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def q(self, sql: str, params: tuple = ()) -> list:
        try:
            return [dict(row) for row in self._conn().execute(sql, params).fetchall()]
        except Exception as e:
            log.warning(f"DB query error: {e}")
            return []

    def scalar(self, sql: str, params: tuple = (), default=0):
        try:
            row = self._conn().execute(sql, params).fetchone()
            return row[0] if row else default
        except Exception:
            return default

    def write(self, sql: str, params: tuple = ()):
        conn = self._conn_rw()
        try:
            conn.execute(sql, params)
            conn.commit()
        finally:
            conn.close()


# =============================================================================
# HTML ŠABLONA
# =============================================================================

HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="cs">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="15">
<title>STARCORE HIVE Dashboard</title>
<style>
  :root {
    --bg: #0d1117; --surface: #161b22; --border: #30363d;
    --text: #c9d1d9; --dim: #6e7681; --accent: #58a6ff;
    --green: #3fb950; --yellow: #d29922; --red: #f85149;
    --cyan: #56d364; --magenta: #bc8cff;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: 'Courier New', monospace; font-size: 13px; }
  header { background: var(--surface); border-bottom: 1px solid var(--border);
           padding: 12px 20px; display: flex; align-items: center; gap: 16px; }
  header h1 { color: var(--accent); font-size: 16px; letter-spacing: 2px; }
  header .ts  { color: var(--dim); font-size: 11px; margin-left: auto; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; padding: 12px; }
  .card { background: var(--surface); border: 1px solid var(--border); border-radius: 6px; padding: 14px; }
  .card h2 { color: var(--accent); font-size: 12px; letter-spacing: 1px;
              border-bottom: 1px solid var(--border); padding-bottom: 8px; margin-bottom: 10px; }
  .full { grid-column: 1 / -1; }
  table { width: 100%; border-collapse: collapse; }
  th { color: var(--dim); font-weight: normal; text-align: left; padding: 3px 8px; font-size: 11px; }
  td { padding: 4px 8px; border-bottom: 1px solid var(--border); vertical-align: top; }
  tr:last-child td { border-bottom: none; }
  .badge { display: inline-block; padding: 1px 6px; border-radius: 3px; font-size: 11px; }
  .green { color: var(--green); }  .red { color: var(--red); }
  .yellow { color: var(--yellow); } .cyan { color: var(--cyan); }
  .dim { color: var(--dim); }  .accent { color: var(--accent); }
  .magenta { color: var(--magenta); }
  .bar-wrap { background: #21262d; border-radius: 3px; height: 8px; margin: 4px 0; }
  .bar-fill { height: 100%; border-radius: 3px; transition: width 0.5s; }
  .bar-green  { background: var(--green); }
  .bar-yellow { background: var(--yellow); }
  .bar-red    { background: var(--red); }
  .stat-row { display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 8px; }
  .stat { display: flex; flex-direction: column; }
  .stat-val { font-size: 22px; font-weight: bold; }
  .stat-lbl { font-size: 10px; color: var(--dim); }
  .action-btn { background: #21262d; color: var(--accent); border: 1px solid var(--border);
                border-radius: 4px; padding: 4px 10px; cursor: pointer; font-size: 11px; }
  .action-btn:hover { background: var(--border); }
  .pill { font-size: 10px; padding: 1px 5px; border-radius: 10px; display: inline-block; }
  .pill-green  { background: #0d4320; color: var(--green); }
  .pill-yellow { background: #2e1c00; color: var(--yellow); }
  .pill-red    { background: #3d0c0c; color: var(--red); }
  .pill-dim    { background: #21262d; color: var(--dim); }
  .pill-cyan   { background: #0d2e1a; color: var(--cyan); }
  #toast { position: fixed; bottom: 20px; right: 20px; background: var(--surface);
           border: 1px solid var(--green); color: var(--green); padding: 10px 16px;
           border-radius: 6px; display: none; font-size: 12px; }
  a { color: var(--accent); text-decoration: none; }
  a:hover { text-decoration: underline; }
  .code { font-family: monospace; font-size: 11px; color: var(--dim); }
</style>
</head>
<body>
<header>
  <h1>⬡ STARCORE HIVE</h1>
  <span class="accent">Live Dashboard</span>
  <span class="dim">·</span>
  <span class="dim" id="db-path"></span>
  <span class="ts" id="ts">načítám...</span>
</header>

<div class="grid" id="root">
  <div class="card full"><p class="dim">Načítám data...</p></div>
</div>

<div id="toast"></div>

<script>
const API = '/api/status';
let data = null;

function pct(a,b){ return b>0 ? Math.round(a*100/b) : 0; }
function ago(ts){
  const s = Math.floor(Date.now()/1000) - ts;
  if(s<0) return '?';
  if(s<60) return s+'s';
  if(s<3600) return Math.floor(s/60)+'m'+('0'+(s%60)).slice(-2)+'s';
  return Math.floor(s/3600)+'h'+('0'+Math.floor((s%3600)/60)).slice(-2)+'m';
}
function pill(text, cls){ return `<span class="pill pill-${cls}">${text}</span>`; }
function agentPill(status){
  if(status==='idle')     return pill(status,'green');
  if(status==='working')  return pill(status,'cyan');
  if(status==='starting') return pill(status,'yellow');
  if(status==='crashed')  return pill(status,'red');
  return pill(status,'dim');
}
function findingPill(sev){
  if(sev==='error')        return pill(sev,'red');
  if(sev==='warning')      return pill(sev,'yellow');
  if(sev==='auto_fixable') return pill(sev,'cyan');
  return pill(sev,'dim');
}
function bar(val,max,cls){
  const p = Math.min(pct(val,max),100);
  return `<div class="bar-wrap"><div class="bar-fill bar-${cls}" style="width:${p}%"></div></div>`;
}

function toast(msg,isErr=false){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.style.borderColor = isErr ? 'var(--red)' : 'var(--green)';
  t.style.color = isErr ? 'var(--red)' : 'var(--green)';
  t.style.display='block';
  setTimeout(()=>t.style.display='none',3000);
}

async function apiPost(url, body){
  try{
    const r = await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const j = await r.json();
    toast(j.message || 'OK');
  }catch(e){ toast('Chyba: '+e,'err'); }
}

function render(d){
  document.getElementById('ts').textContent = new Date().toLocaleTimeString('cs-CZ');
  document.getElementById('db-path').textContent = d.db_path || '';

  const tasks = d.tasks || {};
  const findings = d.findings_summary || {};
  const agents = d.agents || [];
  const files = d.files || {};
  const lib = d.library || {};

  const tTotal  = Object.values(tasks).reduce((a,b)=>a+b,0);
  const tDone   = tasks.done||0;
  const tPend   = tasks.pending||0;
  const tClaim  = tasks.claimed||0;
  const tFail   = tasks.failed||0;

  const fTotal  = d.findings_total_unresolved || 0;
  const fRes    = d.findings_total_resolved || 0;

  let html = '';

  // ── Statistiky přehled ──────────────────────────────────────────────────
  html += `<div class="card full">
  <h2>📊 PŘEHLED</h2>
  <div class="stat-row">
    <div class="stat"><span class="stat-val green">${files.total||0}</span><span class="stat-lbl">indexovaných souborů</span></div>
    <div class="stat"><span class="stat-val accent">${tPend}</span><span class="stat-lbl">čekajících úkolů</span></div>
    <div class="stat"><span class="stat-val cyan">${tClaim}</span><span class="stat-lbl">zpracovávaných</span></div>
    <div class="stat"><span class="stat-val green">${tDone}</span><span class="stat-lbl">dokončených úkolů</span></div>
    <div class="stat"><span class="stat-val red">${tFail}</span><span class="stat-lbl">selhalo</span></div>
    <div class="stat"><span class="stat-val yellow">${fTotal}</span><span class="stat-lbl">otevřených findings</span></div>
    <div class="stat"><span class="stat-val magenta">${lib.count||0}</span><span class="stat-lbl">skriptů v knihovně</span></div>
  </div>
  <div>Úkoly ${bar(tDone, tTotal, 'green')} ${tDone}/${tTotal} (${pct(tDone,tTotal)}% hotovo)</div>
  <div>Findings vyřešeny ${bar(fRes, fTotal+fRes, 'green')} ${fRes}/${fTotal+fRes}</div>
</div>`;

  // ── Agenti ───────────────────────────────────────────────────────────────
  html += `<div class="card"><h2>🤖 AGENTI</h2>
  <table><tr><th>ID</th><th>Role</th><th>Status</th><th>HB</th><th>Done</th><th>Fail</th><th>Akce</th></tr>`;
  for(const a of agents){
    const hbAge = ago(a.last_heartbeat||0);
    const hbWarn = (Date.now()/1000 - (a.last_heartbeat||0)) > 60 ? ' red' : ' dim';
    html += `<tr>
      <td class="code">${a.agent_id}</td>
      <td>${a.role}</td>
      <td>${agentPill(a.status)}</td>
      <td class="${hbWarn}">${hbAge}</td>
      <td class="green">${a.tasks_completed||0}</td>
      <td class="red">${a.tasks_failed||0}</td>
      <td><button class="action-btn"
        onclick="apiPost('/api/agent/restart',{agent_id:'${a.agent_id}'})">↺</button></td>
    </tr>`;
  }
  html += '</table></div>';

  // ── Fronta úkolů ─────────────────────────────────────────────────────────
  const pendByRole = d.pending_by_role || {};
  html += `<div class="card"><h2>📋 FRONTA ÚKOLŮ</h2>
  <table><tr><th>Status</th><th>Počet</th><th>Bar</th></tr>
  <tr><td class="yellow">pending</td><td>${tPend}</td><td>${bar(tPend,tTotal,'yellow')}</td></tr>
  <tr><td class="cyan">claimed</td><td>${tClaim}</td><td>${bar(tClaim,tTotal,'green')}</td></tr>
  <tr><td class="green">done</td><td>${tDone}</td><td>${bar(tDone,tTotal,'green')}</td></tr>
  <tr><td class="red">failed</td><td>${tFail}</td><td>${bar(tFail,tTotal,'red')}</td></tr>
  </table>
  <br><b class="dim">Pending dle role:</b><br>`;
  for(const [role,cnt] of Object.entries(pendByRole)){
    html += `<span class="dim">${role}</span>: <b class="accent">${cnt}</b>&nbsp;&nbsp;`;
  }
  html += `<br><br>
  <button class="action-btn" onclick="apiPost('/api/task/add',{path:'/root/starcore'})">
    + Přidat scan /root/starcore
  </button>`;
  html += `</div>`;

  // ── Findings ─────────────────────────────────────────────────────────────
  html += `<div class="card"><h2>🔍 FINDINGS (otevřené: ${fTotal})</h2>
  <table><tr><th>Typ</th><th>Závažnost</th><th>Počet</th></tr>`;
  for(const f of (d.findings_summary_list||[])){
    html += `<tr>
      <td>${f.finding_type}</td>
      <td>${findingPill(f.severity)}</td>
      <td><b>${f.cnt}</b></td>
    </tr>`;
  }
  html += '</table></div>';

  // ── Index souborů ─────────────────────────────────────────────────────────
  html += `<div class="card"><h2>📁 INDEX SOUBORŮ</h2>
  <div class="stat-row">
    <div class="stat"><span class="stat-val green">${files.total||0}</span><span class="stat-lbl">celkem</span></div>
    <div class="stat"><span class="stat-val accent">${files.sh||0}</span><span class="stat-lbl">.sh</span></div>
    <div class="stat"><span class="stat-val cyan">${files.py||0}</span><span class="stat-lbl">.py</span></div>
    <div class="stat"><span class="stat-val dim">${files.md||0}</span><span class="stat-lbl">.md</span></div>
    <div class="stat"><span class="stat-val dim">${files.other||0}</span><span class="stat-lbl">ostatní</span></div>
  </div>
  <p class="dim">Posledních 5 indexovaných:</p>
  <table>`;
  for(const f of (d.recent_files||[]).slice(0,5)){
    const fname = f.path ? f.path.split('/').pop() : '?';
    html += `<tr>
      <td class="code dim" title="${f.path}">${fname}</td>
      <td class="dim">${f.file_type}</td>
      <td class="dim">${((f.size_bytes||0)/1024).toFixed(1)}KB</td>
    </tr>`;
  }
  html += '</table></div>';

  // ── Knihovna skriptů ─────────────────────────────────────────────────────
  html += `<div class="card"><h2>📚 KNIHOVNA SKRIPTŮ (${lib.count||0})</h2>`;
  if((lib.scripts||[]).length===0){
    html += '<p class="dim">Zatím prázdná – Librarian ještě neprovedl merge.</p>';
  } else {
    html += '<table><tr><th>Skript</th><th>Kategorie</th><th>Verze</th></tr>';
    for(const s of lib.scripts){
      const sname = s.script_path ? s.script_path.split('/').pop() : '?';
      html += `<tr>
        <td class="code">${sname}</td>
        <td>${s.category}</td>
        <td class="dim">v${s.version}</td>
      </tr>`;
    }
    html += '</table>';
  }
  html += '</div>';

  // ── Posledních 10 findings (tabulka) ────────────────────────────────────
  html += `<div class="card full"><h2>🔎 POSLEDNÍCH 10 NÁLEZŮ</h2>
  <table><tr><th>Soubor</th><th>Typ</th><th>Závažnost</th><th>Zpráva</th><th>Detekováno</th></tr>`;
  for(const f of (d.recent_findings||[])){
    const fname = f.file_path ? ('...'+f.file_path.slice(-40)) : '?';
    const ts = f.detected_at ? new Date(f.detected_at*1000).toLocaleString('cs-CZ') : '?';
    html += `<tr>
      <td class="code dim" title="${f.file_path}">${fname}</td>
      <td>${f.finding_type}</td>
      <td>${findingPill(f.severity)}</td>
      <td class="dim">${(f.message||'').slice(0,80)}</td>
      <td class="dim">${ts}</td>
    </tr>`;
  }
  html += '</table></div>';

  // Patička
  html += `<div class="card full" style="text-align:center">
    <span class="dim">Auto-refresh: 15s  •
    <a href="/api/status">JSON API</a>  •
    <a href="/api/findings">Findings JSON</a>  •
    <a href="/api/files">Files JSON</a></span>
  </div>`;

  document.getElementById('root').innerHTML = html;
}

async function load(){
  try{
    const r = await fetch(API+'?ts='+Date.now());
    data = await r.json();
    render(data);
  }catch(e){
    document.getElementById('root').innerHTML =
      `<div class="card full"><p class="red">Chyba načítání API: ${e}</p></div>`;
  }
}

load();
setInterval(load, 15000);
</script>
</body>
</html>
"""


# =============================================================================
# HTTP HANDLER
# =============================================================================

class DashboardHandler(BaseHTTPRequestHandler):
    db: HiveDB = None  # nastaveno při startu serveru

    def log_message(self, fmt, *args):
        pass  # potlačit výchozí access log, píšeme si vlastní

    def _json(self, data: dict, status: int = 200):
        body = json.dumps(data, ensure_ascii=False, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _html(self, body: str):
        data = body.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length > 0:
            try:
                return json.loads(self.rfile.read(length))
            except Exception:
                pass
        return {}

    # ── GET ──────────────────────────────────────────────────────────────────
    def do_GET(self):
        path = urlparse(self.path).path
        db = self.db

        if path == "/" or path == "/dashboard":
            self._html(HTML_TEMPLATE)
            return

        elif path == "/api/status":
            now = int(time.time())
            agents = db.q(
                "SELECT agent_id, role, pid, status, last_heartbeat, "
                "tasks_completed, tasks_failed, current_task_id FROM agents "
                "ORDER BY role, agent_id"
            )
            tasks_raw = db.q("SELECT status, COUNT(*) as cnt FROM tasks GROUP BY status")
            tasks = {r["status"]: r["cnt"] for r in tasks_raw}
            pending_by_role_raw = db.q(
                "SELECT target_role, COUNT(*) as cnt FROM tasks "
                "WHERE status='pending' GROUP BY target_role"
            )
            pending_by_role = {r["target_role"]: r["cnt"] for r in pending_by_role_raw}
            findings_summary = db.q(
                "SELECT finding_type, severity, COUNT(*) as cnt "
                "FROM findings WHERE resolved_at IS NULL "
                "GROUP BY finding_type, severity ORDER BY cnt DESC"
            )
            recent_findings = db.q(
                "SELECT file_path, finding_type, severity, message, detected_at "
                "FROM findings WHERE resolved_at IS NULL "
                "ORDER BY detected_at DESC LIMIT 10"
            )
            files = {
                "total": db.scalar("SELECT COUNT(*) FROM files WHERE status='active'"),
                "sh":    db.scalar("SELECT COUNT(*) FROM files WHERE file_type='sh' AND status='active'"),
                "py":    db.scalar("SELECT COUNT(*) FROM files WHERE file_type='py' AND status='active'"),
                "md":    db.scalar("SELECT COUNT(*) FROM files WHERE file_type='md' AND status='active'"),
                "other": db.scalar("SELECT COUNT(*) FROM files WHERE file_type NOT IN ('sh','py','md') AND status='active'"),
            }
            recent_files = db.q(
                "SELECT path, file_type, size_bytes FROM files "
                "WHERE status='active' ORDER BY last_seen DESC LIMIT 20"
            )
            library = {
                "count": db.scalar("SELECT COUNT(*) FROM library"),
                "scripts": db.q("SELECT script_path, category, version, updated_at FROM library ORDER BY updated_at DESC LIMIT 20"),
            }
            self._json({
                "timestamp": now,
                "db_path": db.db_path,
                "agents": agents,
                "tasks": tasks,
                "pending_by_role": pending_by_role,
                "findings_summary_list": findings_summary,
                "findings_total_unresolved": db.scalar("SELECT COUNT(*) FROM findings WHERE resolved_at IS NULL"),
                "findings_total_resolved":   db.scalar("SELECT COUNT(*) FROM findings WHERE resolved_at IS NOT NULL"),
                "files": files,
                "recent_files": recent_files,
                "library": library,
                "recent_findings": recent_findings,
            })

        elif path == "/api/agents":
            self._json(db.q(
                "SELECT * FROM agents ORDER BY role, agent_id"
            ))

        elif path == "/api/tasks":
            self._json({
                "summary": {r["status"]: r["cnt"] for r in db.q(
                    "SELECT status, COUNT(*) as cnt FROM tasks GROUP BY status")},
                "pending_by_role": {r["target_role"]: r["cnt"] for r in db.q(
                    "SELECT target_role, COUNT(*) as cnt FROM tasks "
                    "WHERE status='pending' GROUP BY target_role")},
                "recent_failed": db.q(
                    "SELECT id, type, target_role, last_error, completed_at "
                    "FROM tasks WHERE status='failed' ORDER BY completed_at DESC LIMIT 20"),
            })

        elif path == "/api/findings":
            self._json(db.q(
                "SELECT id, file_path, agent_role, finding_type, severity, "
                "message, detected_at FROM findings "
                "WHERE resolved_at IS NULL ORDER BY detected_at DESC LIMIT 200"
            ))

        elif path == "/api/files":
            self._json(db.q(
                "SELECT path, file_type, size_bytes, mtime, hash_md5, "
                "last_seen, last_indexed_by FROM files "
                "WHERE status='active' ORDER BY last_seen DESC LIMIT 50"
            ))

        elif path == "/api/library":
            self._json(db.q(
                "SELECT script_path, category, version, checksum, "
                "created_at, updated_at FROM library ORDER BY updated_at DESC"
            ))

        else:
            self.send_response(404)
            self.end_headers()

    # ── POST ─────────────────────────────────────────────────────────────────
    def do_POST(self):
        path = urlparse(self.path).path
        body = self._read_body()

        if path == "/api/task/add":
            target_path = body.get("path", "/root/starcore")
            try:
                conn = sqlite3.connect(self.db.db_path, timeout=5)
                conn.execute("PRAGMA busy_timeout=5000")
                conn.execute(
                    "INSERT INTO tasks (type, target_role, payload_json, priority) "
                    "VALUES (?, ?, ?, ?)",
                    ("scan_dir", "indexer", json.dumps({"path": target_path}), 3),
                )
                conn.commit()
                conn.close()
                log.info(f"Dashboard: přidán scan_dir úkol pro {target_path}")
                self._json({"ok": True, "message": f"scan_dir úkol přidán pro {target_path}"})
            except Exception as e:
                self._json({"ok": False, "message": str(e)}, 500)

        elif path == "/api/agent/restart":
            agent_id = body.get("agent_id", "")
            # Dashboard nemůže přímo restartovat agenta (to je role orchestrátoru),
            # ale může vložit "restart_agent" finding, který orchestrátor při watchdog
            # detekci vyhodnotí. Pro jednoduchost: zapíšeme do findings jako akci.
            # Orchestrátor (watchdog) detekuje crashed agenty sám, takže toto je
            # jen vizuální potvrzení "požadavek zaregistrován".
            try:
                conn = sqlite3.connect(self.db.db_path, timeout=5)
                conn.execute("PRAGMA busy_timeout=5000")
                conn.execute(
                    "UPDATE agents SET status='crashed', last_heartbeat=0 WHERE agent_id=?",
                    (agent_id,),
                )
                conn.commit()
                conn.close()
                log.info(f"Dashboard: požadavek na restart agenta {agent_id}")
                self._json({
                    "ok": True,
                    "message": f"Agent {agent_id} označen jako crashed – orchestrátor ho restartuje při příštím watchdog ticku"
                })
            except Exception as e:
                self._json({"ok": False, "message": str(e)}, 500)

        else:
            self.send_response(404)
            self.end_headers()


# =============================================================================
# VSTUPNÍ BOD
# =============================================================================

def main():
    parser = argparse.ArgumentParser(description="STARCORE HIVE HTTP Dashboard")
    parser.add_argument("--hive-dir", default="/root/starcore/hive")
    parser.add_argument("--port", type=int, default=int(os.environ.get("HTTP_PORT", 7979)))
    parser.add_argument("--bind", default="0.0.0.0")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s][HTTP-DASHBOARD][%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    db_path = os.path.join(args.hive_dir, "registry.db")
    if not os.path.isfile(db_path):
        log.error(f"DB nenalezena: {db_path} – spusť nejdřív orchestrator.py")
        sys.exit(1)

    db = HiveDB(db_path)
    DashboardHandler.db = db

    server = HTTPServer((args.bind, args.port), DashboardHandler)
    log.info(f"Dashboard spuštěn na http://{args.bind}:{args.port}")
    log.info(f"DB: {db_path}")

    def _stop(sig, frame):
        log.info("Zastavuji HTTP server...")
        server.shutdown()

    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)

    server.serve_forever()


if __name__ == "__main__":
    main()
