-- ============================================================================
-- STARCORE HIVE – Registry Database Schema
-- Verze schématu: 1
-- ============================================================================
-- Spuštění: sqlite3 registry.db < schema.sql
-- Idempotentní: lze spustit opakovaně (CREATE TABLE IF NOT EXISTS).
-- ============================================================================

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
PRAGMA busy_timeout = 5000;

-- ---------------------------------------------------------------------------
-- schema_version – pro budoucí migrace struktury DB
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS schema_version (
    version     INTEGER NOT NULL,
    applied_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

-- ---------------------------------------------------------------------------
-- files – centrální index všech souborů sledovaných adresářů
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS files (
    path                TEXT PRIMARY KEY,
    size_bytes          INTEGER,
    mtime               INTEGER,
    hash_md5            TEXT,
    file_type           TEXT,             -- napr. 'sh','py','js','md','conf'...
    content_preview     TEXT,             -- prvních ~500 znaků pro náhled
    first_seen          INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    last_seen           INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    last_indexed_by     TEXT,             -- agent_id, kdo poslední aktualizoval
    status              TEXT NOT NULL DEFAULT 'active'   -- active|deleted|ignored
);
CREATE INDEX IF NOT EXISTS idx_files_status   ON files(status);
CREATE INDEX IF NOT EXISTS idx_files_mtime    ON files(mtime);
CREATE INDEX IF NOT EXISTS idx_files_hash     ON files(hash_md5);
CREATE INDEX IF NOT EXISTS idx_files_type     ON files(file_type);

-- ---------------------------------------------------------------------------
-- findings – výsledky analýzy/inspekce (chyby, varování, duplikáty...)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS findings (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path       TEXT NOT NULL,
    agent_role      TEXT NOT NULL,
    finding_type    TEXT NOT NULL,        -- syntax_error|security_warning|missing_dep|duplicate|needs_manual_review
    severity        TEXT NOT NULL DEFAULT 'warning',  -- info|warning|error|auto_fixable
    message         TEXT,
    detected_at     INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    resolved_at     INTEGER,
    resolved_by     TEXT,
    FOREIGN KEY (file_path) REFERENCES files(path) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_findings_file     ON findings(file_path);
CREATE INDEX IF NOT EXISTS idx_findings_unresolved ON findings(resolved_at) WHERE resolved_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_findings_type     ON findings(finding_type);

-- ---------------------------------------------------------------------------
-- tasks – fronta úkolů pro agenty
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tasks (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    type            TEXT NOT NULL,         -- scan_dir|analyze_file|inspect_file|repair_file|librarian_merge
    target_role     TEXT NOT NULL,         -- která role má úkol vyzvednout
    payload_json    TEXT,                  -- libovolná data úkolu (cesta, parametry...)
    status          TEXT NOT NULL DEFAULT 'pending',  -- pending|claimed|done|failed
    priority        INTEGER NOT NULL DEFAULT 5,        -- 1 = nejvyšší, vyšší číslo = nižší priorita
    claimed_by      TEXT,
    claimed_at      INTEGER,
    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    completed_at    INTEGER,
    retry_count     INTEGER NOT NULL DEFAULT 0,
    max_retries     INTEGER NOT NULL DEFAULT 3,
    last_error      TEXT
);
CREATE INDEX IF NOT EXISTS idx_tasks_pending  ON tasks(target_role, status, priority);
CREATE INDEX IF NOT EXISTS idx_tasks_claimed  ON tasks(status, claimed_at);

-- ---------------------------------------------------------------------------
-- agents – registr živých agentů (heartbeat, role, stav)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS agents (
    agent_id          TEXT PRIMARY KEY,    -- napr. 'inspector-1'
    role              TEXT NOT NULL,
    pid               INTEGER,
    status            TEXT NOT NULL DEFAULT 'starting',  -- starting|idle|working|stopped|crashed
    started_at        INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    last_heartbeat    INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    tasks_completed   INTEGER NOT NULL DEFAULT 0,
    tasks_failed      INTEGER NOT NULL DEFAULT 0,
    current_task_id   INTEGER
);
CREATE INDEX IF NOT EXISTS idx_agents_role ON agents(role);

-- ---------------------------------------------------------------------------
-- library – katalog vygenerovaných/sloučených skriptů (Librarian role)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS library (
    script_path       TEXT PRIMARY KEY,
    category          TEXT,
    source_files_json TEXT,                -- JSON seznam zdrojových souborů
    version           INTEGER NOT NULL DEFAULT 1,
    checksum          TEXT,
    created_at        INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    updated_at        INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

-- ---------------------------------------------------------------------------
-- repair_attempts – sledování pokusů o opravu (pro circuit breaker)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS repair_attempts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path       TEXT NOT NULL,
    attempted_at    INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    outcome         TEXT NOT NULL          -- repaired|no_change|failed
);
CREATE INDEX IF NOT EXISTS idx_repair_attempts_file ON repair_attempts(file_path, attempted_at);

INSERT INTO schema_version (version) SELECT 1 WHERE NOT EXISTS (SELECT 1 FROM schema_version);
