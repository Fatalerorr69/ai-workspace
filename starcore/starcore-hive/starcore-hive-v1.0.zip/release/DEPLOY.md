# STARCORE HIVE v1.0 – Nasazení

## Rychlý start

```bash
# Na fatalab (10.0.0.37):
scp -r starcore-hive-v1.0/ root@10.0.0.37:/tmp/
ssh root@10.0.0.37 "bash /tmp/starcore-hive-v1.0/install.sh"
systemctl start starcore-orchestrator starcore-dashboard
```

## HTTP Dashboard
`http://10.0.0.37:7979`

## Terminálový dashboard
`HIVE_DIR=/root/starcore/hive bash /root/starcore/hive/dashboard_terminal.sh`

## Logy
`journalctl -u starcore-orchestrator -f`
`journalctl -u starcore-agent@inspector-1 -f`

## Konfigurace počtu agentů
`nano /root/starcore/hive/config/agents.json`
`systemctl restart starcore-orchestrator`
