#!/bin/bash
# ============================================================================
# STARCORE HIVE – install.sh
# Instalační skript pro kompletní hive systém.
#
# Použití:
#   bash install.sh [--dry-run] [--hive-dir /root/starcore/hive]
#
# Provádí:
#   1. Kontrola závislostí (python3, sqlite3, bash 5+)
#   2. Vytvoření adresářové struktury
#   3. Kopírování souborů hive systému
#   4. Inicializace databáze
#   5. Nastavení oprávnění (600/700 na citlivé soubory)
#   6. Registrace a povolení systemd služeb
#   7. Migrace legacy souborů (volitelné)
#   8. První spuštění a ověření
# ============================================================================

set -euo pipefail

# ── Konfigurace ─────────────────────────────────────────────────────────────
HIVE_DIR="${HIVE_DIR:-/root/starcore/hive}"
BASE_DIR="$(dirname "$HIVE_DIR")"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DRY_RUN=0

# ── CLI argumenty ────────────────────────────────────────────────────────────
for arg in "$@"; do
    case "$arg" in
        --dry-run)   DRY_RUN=1 ;;
        --hive-dir=*) HIVE_DIR="${arg#*=}"; BASE_DIR="$(dirname "$HIVE_DIR")" ;;
        --help)
            echo "Použití: $0 [--dry-run] [--hive-dir=/root/starcore/hive]"
            exit 0 ;;
    esac
done

# ── Barvy ────────────────────────────────────────────────────────────────────
RED='\033[0;31m' GREEN='\033[0;32m' YELLOW='\033[1;33m'
CYAN='\033[0;36m' BOLD='\033[1m' DIM='\033[2m' NC='\033[0m'

ok()   { echo -e "${GREEN}  ✔${NC} $*"; }
warn() { echo -e "${YELLOW}  ⚠${NC} $*"; }
fail() { echo -e "${RED}  ✘${NC} $*"; }
info() { echo -e "${CYAN}  ℹ${NC} $*"; }
step() { echo -e "\n${BOLD}$*${NC}"; }

run() {
    if [[ $DRY_RUN -eq 1 ]]; then
        echo -e "${DIM}  [DRY-RUN] $*${NC}"
    else
        eval "$@"
    fi
}

ERRORS=0
err() { fail "$*"; (( ERRORS++ )) || true; }

# ============================================================================
echo -e "${BOLD}${CYAN}"
cat << 'BANNER'
  ╔═══════════════════════════════════════════╗
  ║     STARCORE HIVE – Instalační skript     ║
  ║                 v1.0                      ║
  ╚═══════════════════════════════════════════╝
BANNER
echo -e "${NC}"

[[ $DRY_RUN -eq 1 ]] && warn "Běžím v DRY-RUN módu – žádné soubory se nezmění"

# ============================================================================
step "[1/8] Kontrola závislostí"
# ============================================================================

# Root oprávnění
if [[ "$(id -u)" -ne 0 ]]; then
    err "Instalace vyžaduje root oprávnění (sudo bash install.sh)"
    exit 1
fi
ok "Root oprávnění"

# Bash 5+
BASH_VER=$(bash --version | head -1 | grep -oP '\d+\.\d+' | head -1)
BASH_MAJOR=$(echo "$BASH_VER" | cut -d. -f1)
if [[ "$BASH_MAJOR" -ge 5 ]]; then
    ok "Bash $BASH_VER"
else
    err "Vyžadován Bash 5+, nalezen $BASH_VER"
fi

# Python 3.8+
if command -v python3 &>/dev/null; then
    PY_VER=$(python3 --version 2>&1 | grep -oP '\d+\.\d+')
    PY_MAJOR=$(echo "$PY_VER" | cut -d. -f1)
    PY_MINOR=$(echo "$PY_VER" | cut -d. -f2)
    if [[ "$PY_MAJOR" -ge 3 && "$PY_MINOR" -ge 8 ]]; then
        ok "Python $PY_VER"
    else
        err "Vyžadován Python 3.8+, nalezen $PY_VER"
    fi
else
    err "Python3 není k dispozici"
    info "Instalace: apt-get install -y python3"
fi

# sqlite3
if command -v sqlite3 &>/dev/null; then
    ok "sqlite3 $(sqlite3 --version | cut -d' ' -f1)"
else
    warn "sqlite3 není k dispozici – pokouším se doinstalovat..."
    if apt-get install -y sqlite3 -qq 2>/dev/null; then
        ok "sqlite3 nainstalován"
    else
        err "sqlite3 nelze nainstalovat – nainstaluj ručně: apt-get install sqlite3"
    fi
fi

# Volitelné: inotifywait (pro Watcher roli – realtime detekce změn)
if command -v inotifywait &>/dev/null; then
    ok "inotify-tools (volitelné) – dostupné"
else
    warn "inotify-tools není k dispozici – Watcher použije pomalejší mtime fallback"
    info "Instalace (volitelné): apt-get install -y inotify-tools"
fi

if [[ $ERRORS -gt 0 ]]; then
    fail "Kritické závislosti chybí, instalace přerušena"
    exit 1
fi

# ============================================================================
step "[2/8] Vytvoření adresářové struktury"
# ============================================================================

for d in \
    "$HIVE_DIR" \
    "$HIVE_DIR/lib" \
    "$HIVE_DIR/agents" \
    "$HIVE_DIR/config" \
    "$HIVE_DIR/logs/orchestrator" \
    "$HIVE_DIR/logs/indexer" \
    "$HIVE_DIR/logs/analyzer" \
    "$HIVE_DIR/logs/inspector" \
    "$HIVE_DIR/logs/repairer" \
    "$HIVE_DIR/logs/librarian" \
    "$HIVE_DIR/logs/watcher" \
    "$BASE_DIR/bin/optimized" \
    "$BASE_DIR/reports" \
    "$BASE_DIR/archive/legacy-builder"
do
    run "mkdir -p \"$d\""
    ok "Adresář: $d"
done

# ============================================================================
step "[3/8] Kopírování souborů"
# ============================================================================

# Detekujeme, odkud instalujeme (hive/ podadresář vedle install.sh)
SRC="${SCRIPT_DIR}/hive"
if [[ ! -d "$SRC" ]]; then
    err "Zdrojový adresář 'hive/' nenalezen vedle install.sh"
    fail "Ujisti se, že install.sh je vedle adresáře hive/"
    exit 1
fi

FILES_TO_COPY=(
    "schema.sql"
    "orchestrator.py"
    "dashboard_http.py"
    "dashboard_terminal.sh"
    "lib/db.sh"
    "lib/common.sh"
    "agents/agent-worker.sh"
)
for f in "${FILES_TO_COPY[@]}"; do
    src_file="$SRC/$f"
    dst_file="$HIVE_DIR/$f"
    if [[ -f "$src_file" ]]; then
        run "cp \"$src_file\" \"$dst_file\""
        ok "Zkopírován: $f"
    else
        err "Soubor nenalezen: $src_file"
    fi
done

# Spustitelné bity
run "chmod +x \"$HIVE_DIR/orchestrator.py\""
run "chmod +x \"$HIVE_DIR/dashboard_http.py\""
run "chmod +x \"$HIVE_DIR/dashboard_terminal.sh\""
run "chmod +x \"$HIVE_DIR/agents/agent-worker.sh\""

if [[ $ERRORS -gt 0 ]]; then
    fail "$ERRORS souborů se nepodařilo zkopírovat, instalace přerušena"
    exit 1
fi

# ============================================================================
step "[4/8] Inicializace databáze"
# ============================================================================

DB_PATH="$HIVE_DIR/registry.db"
if [[ -f "$DB_PATH" ]]; then
    warn "DB již existuje: $DB_PATH (přeskakuji reinicializaci)"
    # Spustíme schema jako idempotentní upgrade (IF NOT EXISTS)
    run "sqlite3 \"$DB_PATH\" < \"$HIVE_DIR/schema.sql\""
    ok "DB schema ověřeno/upgradováno"
else
    run "sqlite3 \"$DB_PATH\" < \"$HIVE_DIR/schema.sql\""
    ok "DB inicializována: $DB_PATH"
fi

# ============================================================================
step "[5/8] Nastavení oprávnění"
# ============================================================================

# Kořen hive: pouze root může číst/psát
run "chmod 700 \"$HIVE_DIR\""

# DB a konfigurace: 600 (čte jen root)
if [[ -f "$DB_PATH" ]]; then
    run "chmod 600 \"$DB_PATH\""
    ok "DB oprávnění: 600"
fi
if [[ -d "$HIVE_DIR/config" ]]; then
    run "chmod 700 \"$HIVE_DIR/config\""
    ok "Config adresář: 700"
fi

# Skripty: 750 (root čte/spouští, skupina číst)
run "chmod 750 \"$HIVE_DIR/agents/agent-worker.sh\""
run "chmod 750 \"$HIVE_DIR/orchestrator.py\""
run "chmod 750 \"$HIVE_DIR/dashboard_http.py\""
run "chmod 750 \"$HIVE_DIR/dashboard_terminal.sh\""
ok "Oprávnění nastavena"

# ============================================================================
step "[6/8] Instalace systemd jednotek"
# ============================================================================

SYSTEMD_DIR="/etc/systemd/system"

if ! command -v systemctl &>/dev/null; then
    warn "systemctl není dostupný (nejsi na systemd systému?) – přeskakuji"
else
    UNITS=("starcore-orchestrator.service" "starcore-dashboard.service" "starcore-agent@.service")

    for unit in "${UNITS[@]}"; do
        src="$SCRIPT_DIR/systemd/$unit"
        if [[ -f "$src" ]]; then
            run "cp \"$src\" \"$SYSTEMD_DIR/$unit\""
            run "chmod 644 \"$SYSTEMD_DIR/$unit\""
            ok "Nainstalována jednotka: $unit"
        else
            warn "Jednotka nenalezena: $src (přeskakuji)"
        fi
    done

    run "systemctl daemon-reload"
    ok "systemd daemon reloaded"

    # Povolení při startu systému
    run "systemctl enable starcore-orchestrator.service"
    run "systemctl enable starcore-dashboard.service"
    ok "Orchestrátor a Dashboard povoleny pro autostart"
fi

# ============================================================================
step "[7/8] Výchozí konfigurace"
# ============================================================================

CONFIG_FILE="$HIVE_DIR/config/agents.json"
if [[ ! -f "$CONFIG_FILE" ]]; then
    run "cat > \"$CONFIG_FILE\" << 'CFGEOF'
{
  \"scan_interval_seconds\": 300,
  \"watchdog_interval_seconds\": 30,
  \"claim_release_interval\": 60,
  \"librarian_interval_seconds\": 1800,
  \"claim_timeout_seconds\": 300,
  \"agent_stale_seconds\": 60,
  \"scan_dirs\": [\"/root/starcore\", \"/opt\"],
  \"agents\": [
    {\"role\": \"indexer\",   \"count\": 1},
    {\"role\": \"analyzer\",  \"count\": 2},
    {\"role\": \"inspector\", \"count\": 2},
    {\"role\": \"repairer\",  \"count\": 1},
    {\"role\": \"librarian\", \"count\": 1},
    {\"role\": \"watcher\",   \"count\": 1}
  ]
}
CFGEOF"
    ok "Výchozí konfigurace zapsána: $CONFIG_FILE"
else
    ok "Konfigurace již existuje: $CONFIG_FILE"
fi

# ============================================================================
step "[8/8] Ověření instalace"
# ============================================================================

if [[ $DRY_RUN -eq 1 ]]; then
    ok "DRY-RUN: přeskakuji ověření existence souborů (nic nebylo zapsáno)"
    VERIFY_OK=1
else

VERIFY_OK=1

check_file() {
    if [[ -f "$1" ]]; then
        ok "Existuje: $1"
    else
        err "Chybí: $1"
        VERIFY_OK=0
    fi
}

check_file "$HIVE_DIR/schema.sql"
check_file "$HIVE_DIR/orchestrator.py"
check_file "$HIVE_DIR/dashboard_http.py"
check_file "$HIVE_DIR/dashboard_terminal.sh"
check_file "$HIVE_DIR/lib/db.sh"
check_file "$HIVE_DIR/lib/common.sh"
check_file "$HIVE_DIR/agents/agent-worker.sh"
check_file "$HIVE_DIR/registry.db"
check_file "$HIVE_DIR/config/agents.json"

# Syntax check
if [[ $DRY_RUN -eq 0 ]]; then
    bash -n "$HIVE_DIR/lib/db.sh"         && ok "db.sh syntax OK"         || err "db.sh syntax ERROR"
    bash -n "$HIVE_DIR/lib/common.sh"     && ok "common.sh syntax OK"     || err "common.sh syntax ERROR"
    bash -n "$HIVE_DIR/agents/agent-worker.sh" && ok "agent-worker.sh syntax OK" || err "agent-worker.sh syntax ERROR"
    python3 -m py_compile "$HIVE_DIR/orchestrator.py" && ok "orchestrator.py syntax OK" || err "orchestrator.py syntax ERROR"
    python3 -m py_compile "$HIVE_DIR/dashboard_http.py" && ok "dashboard_http.py syntax OK" || err "dashboard_http.py syntax ERROR"

    # Ověření DB
    TABLE_COUNT=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM sqlite_master WHERE type='table';" 2>/dev/null)
    if [[ "${TABLE_COUNT:-0}" -ge 7 ]]; then
        ok "DB obsahuje $TABLE_COUNT tabulek"
    else
        err "DB obsahuje jen $TABLE_COUNT tabulek (očekáváno 7+)"
    fi
fi  # konec vnitřního if DRY_RUN -eq 0
fi  # konec else bloku DRY_RUN -eq 1

# ============================================================================
# Shrnutí
# ============================================================================
echo ""
echo -e "${BOLD}════════════════════════════════════════════${NC}"
if [[ $ERRORS -eq 0 && $VERIFY_OK -eq 1 ]]; then
    echo -e "${GREEN}${BOLD}  ✔ Instalace ÚSPĚŠNĚ dokončena!${NC}"
    echo ""
    echo -e "${BOLD}  Jak spustit:${NC}"
    echo ""
    if command -v systemctl &>/dev/null; then
        echo -e "  ${CYAN}# Spustit orchestrátor (správce agentů):${NC}"
        echo -e "  systemctl start starcore-orchestrator"
        echo ""
        echo -e "  ${CYAN}# Spustit HTTP dashboard:${NC}"
        echo -e "  systemctl start starcore-dashboard"
        echo ""
        echo -e "  ${CYAN}# Sledovat terminálový dashboard:${NC}"
        echo -e "  HIVE_DIR=$HIVE_DIR bash $HIVE_DIR/dashboard_terminal.sh"
        echo ""
        echo -e "  ${CYAN}# Stav systemd služeb:${NC}"
        echo -e "  systemctl status starcore-orchestrator starcore-dashboard"
        echo ""
        echo -e "  ${CYAN}# Logy orchestrátoru:${NC}"
        echo -e "  journalctl -u starcore-orchestrator -f"
    else
        echo -e "  ${CYAN}# Manuální spuštění (bez systemd):${NC}"
        echo -e "  HIVE_DIR=$HIVE_DIR python3 $HIVE_DIR/orchestrator.py &"
        echo -e "  HIVE_DIR=$HIVE_DIR python3 $HIVE_DIR/dashboard_http.py &"
        echo -e "  HIVE_DIR=$HIVE_DIR bash $HIVE_DIR/dashboard_terminal.sh"
    fi
    echo ""
    echo -e "  ${CYAN}# HTTP Dashboard (v prohlížeči nebo z mobilu):${NC}"
    echo -e "  http://$(hostname -I | awk '{print $1}' 2>/dev/null || echo 'SERVER_IP'):7979"
    echo ""
    echo -e "  ${DIM}  Konfigurace: $HIVE_DIR/config/agents.json${NC}"
    echo -e "  ${DIM}  DB:          $HIVE_DIR/registry.db${NC}"
    echo -e "  ${DIM}  Logy:        $HIVE_DIR/logs/${NC}"
else
    echo -e "${RED}${BOLD}  ✘ Instalace dokončena s $ERRORS chybami!${NC}"
    echo -e "  Zkontroluj výpis výše a oprav chyby."
    exit 1
fi
echo -e "${BOLD}════════════════════════════════════════════${NC}"
