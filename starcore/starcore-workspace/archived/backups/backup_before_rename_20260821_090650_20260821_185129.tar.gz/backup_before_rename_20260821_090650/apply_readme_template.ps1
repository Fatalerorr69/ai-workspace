# apply_readme_template.ps1
$base = "E:\Git"
$log = Join-Path $base "readme_apply_log.txt"
Remove-Item $log -ErrorAction SilentlyContinue
function Log($t){ $t | Out-File $log -Append -Encoding UTF8; Write-Output $t }

$template = @"
# {NAME}

**Krátký popis:** Vložte stručný popis projektu.

## Instalace
1. Krok 1
2. Krok 2

## Použití
Příklady použití.

## Příspěvky
Popis jak přispívat.

## Licence
MIT
"@

Log "=== APPLY README TEMPLATE START ==="
Log "Čas: $(Get-Date)"

Get-ChildItem $base -Directory | ForEach-Object {
    $dir = $_.FullName
    $name = $_.Name
    if (-not (Test-Path (Join-Path $dir ".git"))) { Log "SKIP $name - no .git"; return }
    $readmePath = Join-Path $dir "README.md"
    $apply = $false
    if (-not (Test-Path $readmePath)) { $apply = $true; Log "$name - README chybí -> vytvořím" }
    else {
        $len = (Get-Content $readmePath -Raw).Length
        if ($len -lt 120) { $apply = $true; Log "$name - README krátký ($len zn) -> přepisuji" }
        else { Log "$name - README OK ($len zn)"; continue }
    }
    if ($apply) {
        $content = $template -replace "\{NAME\}", $name
        $content | Out-File $readmePath -Encoding UTF8
        git -C $dir add README.md 2>&1 | Out-File $log -Append -Encoding UTF8
        try {
            git -C $dir commit -m "Add/Update README from template" 2>&1 | Out-File $log -Append -Encoding UTF8
        } catch {
            Log "Commit selhal (možná žádné změny)."
        }
        $origin = git -C $dir remote get-url origin 2>$null
        if ($origin) {
            $branch = git -C $dir rev-parse --abbrev-ref HEAD 2>$null
            if (-not $branch) { $branch = "main" }
            git -C $dir push -u origin $branch 2>&1 | Out-File $log -Append -Encoding UTF8
            Log "Pushed README to origin/$branch"
        }
    }
}

Log "=== APPLY README TEMPLATE END ==="
Log "Log: $log"
