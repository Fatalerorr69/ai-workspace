# starcore-platform

Krátký popis projektu.
