param(
    [string]$Root = "E:\Git",
    [string]$OutputJson = "ecosystem_projects.json",
    [string]$OutputMd = "ecosystem_projects.md"
)

$projects = @()

Get-ChildItem $Root -Directory | ForEach-Object {
    $name = $_.Name
    $path = $_.FullName
    $hasGit = Test-Path (Join-Path $path ".git")

    # Hrubá klasifikace podle názvu
    $platform = if ($name -match "android") { "ANDROID" }
                elseif ($name -match "UltraOS|CustomUbuntuServer|RPI|rpi|Raspberry|WSL") { "LINUX" }
                elseif ($name -match "WINPE|Terminal_Mini_OS|Run_OS_from_fyzDisk_on_win|Powershell|VScode|Workspace") { "WINDOWS" }
                else { "MIXED/OTHER" }

    $category = if ($name -match "Workspace|VScode|universal-ai-codespace") { "PRACOVNI_PROSTREDI" }
                elseif ($name -match "SuperNastroj|Starko Universal PenTest|MD_installer") { "NASTROJE/UTILITY" }
                elseif ($name -match "starcore-platform|STARCORE-ANDROID|Starcore vNEXT") { "STARCORE_CORE" }
                else { "OTHER" }

    $projects += [pscustomobject]@{
        Name      = $name
        Path      = $path
        HasGit    = $hasGit
        Platform  = $platform
        Category  = $category
    }
}

$projects | ConvertTo-Json -Depth 4 | Set-Content $OutputJson -Encoding UTF8

$md = "# Starcore Ecosystem Projects`n`n"
foreach ($p in $projects) {
    $md += "## $($p.Name)`n"
    $md += "- **Path:** $($p.Path)`n"
    $md += "- **Platform:** $($p.Platform)`n"
    $md += "- **Category:** $($p.Category)`n"
    $md += "- **Git repo:** " + ($(if ($p.HasGit) { "ANO" } else { "NE" })) + "`n`n"
}
Set-Content $OutputMd $md -Encoding UTF8

Write-Host "Ecosystem audit done. JSON: $OutputJson, MD: $OutputMd"
