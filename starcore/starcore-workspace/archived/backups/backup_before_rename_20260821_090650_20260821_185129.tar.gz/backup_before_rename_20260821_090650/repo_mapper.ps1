# repo_mapper.ps1
# Interaktivní návrhy mapování lokálních složek na GitHub repozitáře a přejmenování
$base = "E:\Git"
$githubOwner = "Fatalerorr69"
function NormalizeName($name){
    $n = $name.Trim()
    $n = $n -replace '[^A-Za-z0-9\-_ ]',''
    $n = $n -replace '\s+','-'
    return $n.ToLower()
}
Write-Output "=== REPO MAPPER ==="
Get-ChildItem $base -Directory | ForEach-Object {
    $name = $_.Name
    $candidate = NormalizeName $name
    $exists = $false
    try { gh repo view "$githubOwner/$candidate" --json name > $null 2>$null; $exists = $true } catch {}
    if ($exists) {
        Write-Output "$name -> doporučený název: $candidate (repo existuje na GitHubu)"
    } else {
        Write-Output "$name -> doporučený název: $candidate (repo NEexistuje)"
    }
}
Write-Output "Pro přejmenování složky použij příkaz:"
Write-Output "Rename-Item -Path 'E:\Git\OLD_NAME' -NewName 'NEW_NAME'"
