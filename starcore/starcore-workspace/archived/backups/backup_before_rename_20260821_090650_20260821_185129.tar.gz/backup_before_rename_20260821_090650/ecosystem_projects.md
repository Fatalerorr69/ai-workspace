# Starcore Ecosystem Projects

## _STARCORE_PROJECT_INTELLIGENCE
- **Path:** E:\GIT\_STARCORE_PROJECT_INTELLIGENCE
- **Platform:** MIXED/OTHER
- **Category:** OTHER
- **Git repo:** ANO

## AI-PROJECT-ANALYZER
- **Path:** E:\GIT\AI-PROJECT-ANALYZER
- **Platform:** MIXED/OTHER
- **Category:** OTHER
- **Git repo:** ANO

## Android_kit_ OS
- **Path:** E:\GIT\Android_kit_ OS
- **Platform:** ANDROID
- **Category:** OTHER
- **Git repo:** ANO

## CustomUbuntuServer
- **Path:** E:\GIT\CustomUbuntuServer
- **Platform:** LINUX
- **Category:** OTHER
- **Git repo:** ANO

## Genesis Aeterna
- **Path:** E:\GIT\Genesis Aeterna
- **Platform:** MIXED/OTHER
- **Category:** OTHER
- **Git repo:** ANO

## HerniOS
- **Path:** E:\GIT\HerniOS
- **Platform:** MIXED/OTHER
- **Category:** OTHER
- **Git repo:** ANO

## MD_installer
- **Path:** E:\GIT\MD_installer
- **Platform:** MIXED/OTHER
- **Category:** NASTROJE/UTILITY
- **Git repo:** ANO

## modules
- **Path:** E:\GIT\modules
- **Platform:** MIXED/OTHER
- **Category:** OTHER
- **Git repo:** NE

## Powershell
- **Path:** E:\GIT\Powershell
- **Platform:** WINDOWS
- **Category:** OTHER
- **Git repo:** ANO

## Raspberry Pi 5 multifunkční systémy a automatizace
- **Path:** E:\GIT\Raspberry Pi 5 multifunkční systémy a automatizace
- **Platform:** LINUX
- **Category:** OTHER
- **Git repo:** ANO

## recalbox diag
- **Path:** E:\GIT\recalbox diag
- **Platform:** MIXED/OTHER
- **Category:** OTHER
- **Git repo:** ANO

## RPI_nymea
- **Path:** E:\GIT\RPI_nymea
- **Platform:** LINUX
- **Category:** OTHER
- **Git repo:** ANO

## rpi5-homeassistant-suite
- **Path:** E:\GIT\rpi5-homeassistant-suite
- **Platform:** LINUX
- **Category:** OTHER
- **Git repo:** ANO

## Run_OS_from_fyzDisk_on_win
- **Path:** E:\GIT\Run_OS_from_fyzDisk_on_win
- **Platform:** WINDOWS
- **Category:** OTHER
- **Git repo:** ANO

## Starcore vNEXT
- **Path:** E:\GIT\Starcore vNEXT
- **Platform:** MIXED/OTHER
- **Category:** STARCORE_CORE
- **Git repo:** ANO

## STARCORE-ANDROID
- **Path:** E:\GIT\STARCORE-ANDROID
- **Platform:** ANDROID
- **Category:** STARCORE_CORE
- **Git repo:** ANO

## starcore-platform
- **Path:** E:\GIT\starcore-platform
- **Platform:** MIXED/OTHER
- **Category:** STARCORE_CORE
- **Git repo:** ANO

## starcore-platform-backup
- **Path:** E:\GIT\starcore-platform-backup
- **Platform:** MIXED/OTHER
- **Category:** STARCORE_CORE
- **Git repo:** ANO

## Starko Universal PenTest
- **Path:** E:\GIT\Starko Universal PenTest
- **Platform:** MIXED/OTHER
- **Category:** NASTROJE/UTILITY
- **Git repo:** ANO

## Starko_OS_kali
- **Path:** E:\GIT\Starko_OS_kali
- **Platform:** MIXED/OTHER
- **Category:** OTHER
- **Git repo:** ANO

## StarkoRecovery
- **Path:** E:\GIT\StarkoRecovery
- **Platform:** MIXED/OTHER
- **Category:** OTHER
- **Git repo:** ANO

## SuperNastroj
- **Path:** E:\GIT\SuperNastroj
- **Platform:** MIXED/OTHER
- **Category:** NASTROJE/UTILITY
- **Git repo:** ANO

## SuperNastroj_v5
- **Path:** E:\GIT\SuperNastroj_v5
- **Platform:** MIXED/OTHER
- **Category:** NASTROJE/UTILITY
- **Git repo:** ANO

## Terminal_Mini_OS
- **Path:** E:\GIT\Terminal_Mini_OS
- **Platform:** WINDOWS
- **Category:** OTHER
- **Git repo:** ANO

## Ultimate Raspberry Pi 5 All-in-One Installer
- **Path:** E:\GIT\Ultimate Raspberry Pi 5 All-in-One Installer
- **Platform:** LINUX
- **Category:** OTHER
- **Git repo:** ANO

## UltraOS
- **Path:** E:\GIT\UltraOS
- **Platform:** LINUX
- **Category:** OTHER
- **Git repo:** ANO

## universal-ai-codespace
- **Path:** E:\GIT\universal-ai-codespace
- **Platform:** MIXED/OTHER
- **Category:** PRACOVNI_PROSTREDI
- **Git repo:** ANO

## VMconsole
- **Path:** E:\GIT\VMconsole
- **Platform:** MIXED/OTHER
- **Category:** OTHER
- **Git repo:** ANO

## VScode
- **Path:** E:\GIT\VScode
- **Platform:** WINDOWS
- **Category:** PRACOVNI_PROSTREDI
- **Git repo:** ANO

## WINPE RECOVERY — DARK PRO EDITION
- **Path:** E:\GIT\WINPE RECOVERY — DARK PRO EDITION
- **Platform:** WINDOWS
- **Category:** OTHER
- **Git repo:** ANO

## Workspace
- **Path:** E:\GIT\Workspace
- **Platform:** WINDOWS
- **Category:** PRACOVNI_PROSTREDI
- **Git repo:** ANO

## WSL
- **Path:** E:\GIT\WSL
- **Platform:** LINUX
- **Category:** OTHER
- **Git repo:** ANO


