# ============================================
# KOMBINOVANÝ AUDIT LOKÁLNÍHO E:\Git + GitHub účtu Fatalerorr69
# ============================================

$report = "E:\Git\combined_audit_report.txt"
Remove-Item $report -ErrorAction SilentlyContinue

function Log {
    param([string]$text)
    $text | Out-File $report -Append -Encoding UTF8
}

Log "=== KOMBINOVANÝ AUDIT START ==="
Log "Čas: $(Get-Date)"
Log ""

# --------------------------------------------
# 1) AUDIT LOKÁLNÍHO ÚLOŽIŠTĚ
# --------------------------------------------

Log "=== AUDIT LOKÁLNÍHO ÚLOŽIŠTĚ E:\Git ==="

$dirs = Get-ChildItem "E:\Git" -Directory

foreach ($d in $dirs) {
    Log ""
    Log "---- Projekt: $($d.Name) ----"
    Log "Cesta: $($d.FullName)"

    $gitPath = Join-Path $d.FullName ".git"

    if (Test-Path $gitPath) {
        Log "Typ: Git repozitář"

        Log "git status:"
        git -C $d.FullName status | Out-File $report -Append -Encoding UTF8

        Log "Posledních 10 commitů:"
        git -C $d.FullName log --oneline -n 10 | Out-File $report -Append -Encoding UTF8

        Log "Remote:"
        git -C $d.FullName remote -v | Out-File $report -Append -Encoding UTF8

        Log "Aktuální větev:"
        git -C $d.FullName rev-parse --abbrev-ref HEAD | Out-File $report -Append -Encoding UTF8
    }
    else {
        Log "Typ: NENÍ Git repozitář"
        Log "Doporučení: Pokud má být verzován → spusť 'git init' a nastav remote."
    }
}

# --------------------------------------------
# 2) AUDIT GITHUB REPOZITÁŘŮ
# --------------------------------------------

Log ""
Log "=== AUDIT GITHUB ÚČTU Fatalerorr69 ==="

try {
    $repos = gh repo list Fatalerorr69 --json name -q '.[].name'
} catch {
    Log "CHYBA: GitHub CLI není přihlášené. Spusť 'gh auth login'."
    $repos = @()
}

foreach ($repo in $repos) {
    Log ""
    Log "---- GitHub repo: $repo ----"

    try {
        $info = gh repo view "Fatalerorr69/$repo" --json name,description,visibility,defaultBranchRef,pushedAt,url,isPrivate,isFork,isArchived,diskUsage

        Log "Název: $($info.name)"
        Log "Popis: $($info.description)"
        Log "Viditelnost: $($info.visibility)"
        Log "Default větev: $($info.defaultBranchRef.name)"
        Log "Poslední push: $($info.pushedAt)"
        Log "URL: $($info.url)"
        Log "Velikost: $($info.diskUsage) KB"
        Log "Private: $($info.isPrivate)"
        Log "Fork: $($info.isFork)"
        Log "Archivovaný: $($info.isArchived)"
    } catch {
        Log "CHYBA: Nepodařilo se načíst metadata."
    }

    # README přes GitHub API
    try {
        $readmeBase64 = gh api "repos/Fatalerorr69/$repo/readme" --jq '.content' 2>$null

        if ($readmeBase64) {
            $bytes = [System.Convert]::FromBase64String($readmeBase64)
            $readmeText = [System.Text.Encoding]::UTF8.GetString($bytes)

            Log "README – prvních 20 řádků:"
            ($readmeText -split "`n" | Select-Object -First 20) | Out-File $report -Append -Encoding UTF8
        }
        else {
            Log "README: Nenalezeno."
        }
    } catch {
        Log "README: CHYBA při načítání."
    }
}

# --------------------------------------------
# 3) DOPORUČENÍ
# --------------------------------------------

Log ""
Log "=== DOPORUČENÍ ==="
Log "- Sjednotit názvy složek s názvy GitHub repozitářů."
Log "- U složek bez .git rozhodnout, které mají být verzované."
Log "- Vytvořit jednotnou README šablonu."
Log "- Nastavit CI/CD (GitHub Actions) pro aktivní projekty."
Log "- Zavést pravidelný audit (měsíčně)."

Log ""
Log "=== AUDIT DOKONČEN ==="
Log "Report: $report"
