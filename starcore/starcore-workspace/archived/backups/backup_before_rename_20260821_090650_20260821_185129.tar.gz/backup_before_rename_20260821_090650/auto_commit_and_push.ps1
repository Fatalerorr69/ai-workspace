param([string]$Root = "E:\Git")

Get-ChildItem $Root -Directory | ForEach-Object {
    $p = $_.FullName
    if (Test-Path (Join-Path $p ".git")) {
        $headExists = (git -C $p rev-parse --verify HEAD 2>$null) -ne $null
        if (-not $headExists) {
            git -C $p add -A
            git -C $p commit -m "Initial commit - automated" 2>$null
            try { git -C $p push -u origin main 2>$null } catch { }
        } else {
            $status = git -C $p status --porcelain
            if ($status) {
                git -C $p add -A
                git -C $p commit -m "Auto commit: sync local changes" 2>$null
                try { git -C $p push 2>$null } catch { }
            }
        }
    }
}
