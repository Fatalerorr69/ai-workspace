# {{NAME}}

## Účel a zaměření
Krátký popis projektu a jeho role v ekosystému Starcore.

## Platforma
WINDOWS / LINUX / ANDROID

## Kategorie
CORE_PLATFORM / CORE_ANDROID / WORKSPACE / TOOLS / INFRA

## Hlavní funkce
- Funkce 1
- Funkce 2

## Integrace
- Jak se napojuje na starcore-platform: (moduly, API, CLI)
- Jak se napojuje na starcore-android: (Termux, bridge)

## Instalace
- Kroky instalace

## CI / Release
- Odkaz na workflow v .github/workflows
