# Definice projektu: backup_before_rename_20260821_090650

Popis, účel, funkce.
