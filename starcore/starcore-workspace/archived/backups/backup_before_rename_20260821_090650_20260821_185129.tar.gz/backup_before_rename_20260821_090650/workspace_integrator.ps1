# workspace_integrator.ps1
# Automatická integrace workspace, kategorizace projektů, generování VSCode a DevContainer

$base = "E:\Git"
$catalog = @()

function Add-Project {
    param(
        [string]$Name,
        [string]$Category,
        [string]$Platform
    )

    $catalog += [pscustomobject]@{
        Name     = $Name
        Category = $Category
        Platform = $Platform
        Path     = Join-Path $base $Name
        Timestamp = (Get-Date)
    }

    # VSCode settings
    $vscode = Join-Path $base $Name ".vscode"
    if (-not (Test-Path $vscode)) { New-Item -ItemType Directory -Path $vscode | Out-Null }

    @{
        "editor.formatOnSave" = $true
        "files.eol"           = "`n"
        "terminal.integrated.defaultProfile.windows" = "PowerShell"
    } | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $vscode "settings.json")

    # DevContainer for STARCORE projects
    if ($Name -in @("starcore-platform","STARCORE-ANDROID")) {
        $dev = Join-Path $base $Name ".devcontainer"
        if (-not (Test-Path $dev)) { New-Item -ItemType Directory -Path $dev | Out-Null }

        @"
{
  "name": "$Name DevContainer",
  "image": "mcr.microsoft.com/devcontainers/base:ubuntu",
  "features": {},
  "postCreateCommand": "bash ./setup.sh || true"
}
"@ | Set-Content (Join-Path $dev "devcontainer.json")
    }
}

# Kategorizace
Add-Project "_STARCORE_PROJECT_INTELLIGENCE" "TOOLS" "WINDOWS"
Add-Project "AI-PROJECT-ANALYZER" "TOOLS" "WINDOWS"
Add-Project "Android_kit_ OS" "ANDROID" "ANDROID"
Add-Project "CustomUbuntuServer" "OS" "LINUX"
Add-Project "Genesis Aeterna" "TOOLS" "LINUX"
Add-Project "HerniOS" "OS" "WINDOWS"
Add-Project "MD_installer" "TOOLS" "WINDOWS"
Add-Project "Powershell" "TOOLS" "WINDOWS"
Add-Project "Raspberry Pi 5 multifunkční systémy a automatizace" "OS" "LINUX"
Add-Project "recalbox diag" "OS" "LINUX"
Add-Project "RPI_nymea" "OS" "LINUX"
Add-Project "rpi5-homeassistant-suite" "OS" "LINUX"
Add-Project "Run_OS_from_fyzDisk_on_win" "OS" "WINDOWS"
Add-Project "Starcore vNEXT" "OS" "LINUX"
Add-Project "STARCORE-ANDROID" "CORE" "ANDROID"
Add-Project "starcore-platform" "CORE" "LINUX"
Add-Project "SuperNastroj" "TOOLS" "WINDOWS"
Add-Project "SuperNastroj_v5" "TOOLS" "WINDOWS"
Add-Project "Terminal_Mini_OS" "OS" "WINDOWS"
Add-Project "Ultimate Raspberry Pi 5 All-in-One Installer" "OS" "LINUX"
Add-Project "UltraOS" "OS" "LINUX"
Add-Project "universal-ai-codespace" "WORKSPACE" "LINUX"
Add-Project "VScode" "WORKSPACE" "WINDOWS"
Add-Project "Workspace" "WORKSPACE" "WINDOWS"

# Export katalogu
$catalog | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $base "workspace-catalog.json")

Write-Output "Workspace integrace dokončena."
Write-Output "Katalog: workspace-catalog.json"
