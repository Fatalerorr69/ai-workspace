# E:\Git\starcore_project_analyzer.ps1
param(
  [string]$Root = "E:\Git",
  [string]$ManifestFile = "E:\Git\starcore_manifest.yaml"
)

$projects = @(
  @{ Name="starcore-platform"; OS="LINUX"; Role="AI OS / Proxmox hypervisor"; Group="CORE_PLATFORM" },
  @{ Name="STARCORE-ANDROID"; OS="ANDROID"; Role="Termux klient, auto-connect, audit"; Group="CORE_ANDROID" },
  @{ Name="SuperNastroj_v5"; OS="LINUX,WINDOWS"; Role="Nástrojová sada"; Group="TOOLS" },
  @{ Name="VScode"; OS="WINDOWS,LINUX"; Role="Editor / workspace config"; Group="WORKSPACE" },
  @{ Name="Workspace"; OS="WINDOWS,LINUX"; Role="Meta-workspace"; Group="WORKSPACE" },
  @{ Name="Powershell"; OS="WINDOWS"; Role="Automatizace, dashboard"; Group="TOOLS" }
)

$manifestLines = @("projects:")

foreach ($p in $projects) {
  $path = Join-Path $Root $p.Name
  $hasGit = Test-Path (Join-Path $path ".git")
  $readme = Join-Path $path "README.md"

  $manifestLines += "  - name: $($p.Name)"
  $manifestLines += "    os: $($p.OS)"
  $manifestLines += "    role: $($p.Role)"
  $manifestLines += "    group: $($p.Group)"
  $manifestLines += "    path: $path"
  $manifestLines += "    git: $hasGit"

  if ($hasGit -and -not (Test-Path $readme)) {
    @"
# $($p.Name)

**Kategorie:** $($p.Group)  
**OS:** $($p.OS)

## Účel
$($p.Role)

## Hlavní funkce
- Doplnit konkrétní moduly a scénáře použití.

"@ | Set-Content -Encoding UTF8 $readme
  }
}

$manifestLines | Set-Content -Encoding UTF8 $ManifestFile
Write-Host "Manifest aktualizován: $ManifestFile"
