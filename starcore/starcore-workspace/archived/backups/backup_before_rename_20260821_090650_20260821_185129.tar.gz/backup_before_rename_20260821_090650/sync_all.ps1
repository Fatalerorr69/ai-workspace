# sync_all.ps1
$base = "E:\Git"
$log = Join-Path $base "sync_all_log.txt"
Remove-Item $log -ErrorAction SilentlyContinue
function Log($t){ $t | Out-File $log -Append -Encoding UTF8; Write-Output $t }

Log "=== SYNC ALL START ==="
Log "Čas: $(Get-Date)"

Get-ChildItem $base -Directory | ForEach-Object {
    $dir = $_.FullName
    $name = $_.Name
    if (-not (Test-Path (Join-Path $dir ".git"))) {
        Log "SKIP $name - no .git"
        return
    }
    Log "=== $name ==="

    $status = git -C $dir status --porcelain
    if ($status) {
        Log "Uncommitted changes exist:"
        $status | Out-File $log -Append -Encoding UTF8
        Log "Doporučení: commitnout nebo stashnout ručně. Skript NEprovádí automatický stash."
        Log ""
        return
    }

    Log "Fetching origin..."
    git -C $dir fetch origin 2>&1 | Out-File $log -Append -Encoding UTF8

    $branch = git -C $dir rev-parse --abbrev-ref HEAD 2>$null
    if (-not $branch) { Log "Nelze zjistit větev (HEAD?). Přeskočeno."; Log ""; return }

    # compute behind/ahead
    $behindAhead = git -C $dir rev-list --left-right --count origin/$branch...$branch 2>$null
    $behind = 0; $ahead = 0
    if ($behindAhead) {
        $parts = $behindAhead -split "`t"
        if ($parts.Length -ge 2) { $behind = [int]$parts[0]; $ahead = [int]$parts[1] }
    }

    Log "Větev: $branch; behind: $behind; ahead: $ahead"

    if ($behind -gt 0) {
        Log "Pull (rebase) origin/$branch..."
        git -C $dir pull --rebase origin $branch 2>&1 | Out-File $log -Append -Encoding UTF8
    }

    if ($ahead -gt 0) {
        Log "Pushing local commits..."
        git -C $dir push origin $branch 2>&1 | Out-File $log -Append -Encoding UTF8
    }

    Log ""
}

Log "=== SYNC ALL END ==="
Log "Log: $log"
