param(
    [switch]$Classify,
    [switch]$Audit,
    [switch]$Readme,
    [switch]$Sync,
    [string]$Root = "E:\Git"
)
Import-Module "$PSScriptRoot\modules\Starcore.Workspace.psm1" -ErrorAction SilentlyContinue
Import-Module "$PSScriptRoot\modules\Starcore.Audit.psm1" -ErrorAction SilentlyContinue
Import-Module "$PSScriptRoot\modules\Starcore.Sync.psm1" -ErrorAction SilentlyContinue
Import-Module "$PSScriptRoot\modules\Starcore.Readme.psm1" -ErrorAction SilentlyContinue

Write-Host "=== STARCORE CONTROL ==="

if ($Classify) {
    $profile = Get-StarcoreProjectProfile -Root $Root
    $profile | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $Root "workspace_profile.json")
    $profile | Format-Table
}

if ($Readme) { Invoke-ReadmeTemplateApply -Root $Root }

if ($Audit) {
    $reports = @()
    Get-ChildItem $Root -Directory | ForEach-Object {
        $reports += Invoke-ProjectAudit -ProjectPath $_.FullName
    }
    $reports | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $Root "project_audit.json")
    Write-Host "Audit uložen: project_audit.json"
}

if ($Sync) {
    Get-ChildItem $Root -Directory | ForEach-Object {
        $p = $_.FullName
        if (Test-Path (Join-Path $p ".git")) {
            try { SafeSync -RepoPath $p -AutoStash } catch { Write-Warning "SafeSync failed for $p" }
            try { PushWithRetry -RepoPath $p } catch { Write-Warning "PushWithRetry failed for $p" }
        }
    }
}

Write-Host "=== DONE ==="
