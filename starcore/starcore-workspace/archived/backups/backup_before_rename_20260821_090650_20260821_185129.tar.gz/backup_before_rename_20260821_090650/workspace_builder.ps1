# workspace_builder.ps1
# Nasazení šablon: devcontainer + GitHub Actions + dependabot do vybraných repozitářů
$base = "E:\Git"
$log = Join-Path $base "workspace_builder_log.txt"
Remove-Item $log -ErrorAction SilentlyContinue
function Log($t){ $t | Out-File $log -Append -Encoding UTF8; Write-Output $t }

# Šablony (základní)
$devcontainer = @"
{
  ""name"": ""STARCORE DevContainer"",
  ""image"": ""mcr.microsoft.com/devcontainers/base:ubuntu"",
  ""features"": {},
  ""postCreateCommand"": ""./scripts/setup-dev.sh || true""
}
"@

$ciYaml = @"
name: CI
on: [push, pull_request]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up Node
        uses: actions/setup-node@v4
        with:
          node-version: '18'
      - name: Install
        run: npm ci || true
      - name: Lint
        run: npm run lint || true
      - name: Test
        run: npm test || true
"@

$dependabot = @"
version: 2
updates:
  - package-ecosystem: npm
    directory: /
    schedule:
      interval: weekly
"@

Log "=== WORKSPACE BUILDER START ==="
Log "Čas: $(Get-Date)"

# target repos: starcore-platform, STARCORE-ANDROID, SuperNastroj_v5
$targets = @("starcore-platform","STARCORE-ANDROID","SuperNastroj_v5")
foreach ($t in $targets) {
    $dir = Join-Path $base $t
    if (-not (Test-Path $dir)) { Log "SKIP $t - složka neexistuje"; continue }
    if (-not (Test-Path (Join-Path $dir ".git"))) { Log "SKIP $t - není git repo"; continue }

    Log "---- $t ----"
    # create .devcontainer
    $devDir = Join-Path $dir ".devcontainer"
    if (-not (Test-Path $devDir)) { New-Item -ItemType Directory -Path $devDir | Out-Null }
    $devFile = Join-Path $devDir "devcontainer.json"
    $devcontainer | Out-File $devFile -Encoding UTF8
    Log "DevContainer vytvořen."

    # create .github/workflows/ci.yml
    $workflows = Join-Path $dir ".github\workflows"
    if (-not (Test-Path $workflows)) { New-Item -ItemType Directory -Path $workflows -Force | Out-Null }
    $ciFile = Join-Path $workflows "ci.yml"
    $ciYaml | Out-File $ciFile -Encoding UTF8
    Log "CI workflow vytvořen."

    # create .github/dependabot.yml
    $dependabotFile = Join-Path $dir ".github\dependabot.yml"
    $dependabot | Out-File $dependabotFile -Encoding UTF8
    Log "Dependabot konfigurace vytvořena."

    # commit & push
    git -C $dir add .devcontainer .github 2>&1 | Out-File $log -Append -Encoding UTF8
    try {
        git -C $dir commit -m "Add devcontainer and CI templates" 2>&1 | Out-File $log -Append -Encoding UTF8
    } catch { Log "Commit selhal (možná žádné změny)." }
    $origin = git -C $dir remote get-url origin 2>$null
    if ($origin) {
        $branch = git -C $dir rev-parse --abbrev-ref HEAD 2>$null
        if (-not $branch) { $branch = "main" }
        git -C $dir push -u origin $branch 2>&1 | Out-File $log -Append -Encoding UTF8
        Log "Pushed templates to origin/$branch"
    } else {
        Log "No origin; templates committed locally."
    }
    Log ""
}

Log "=== WORKSPACE BUILDER END ==="
Log "Log: $log"
