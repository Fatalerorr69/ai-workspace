param([string]$Root = "E:\Git")

$timestamp = (Get-Date).ToString("yyyyMMdd_HHmmss")
$backup = Join-Path $Root "backup_before_rename_$timestamp"
Write-Host "Creating backup of $Root -> $backup"
Copy-Item -Path $Root -Destination $backup -Recurse -Force

Get-ChildItem -Path $Root -Directory | ForEach-Object {
    $origName = $_.Name
    if ($origName -in @("modules","termux_install")) { return }
    $newName = $origName.ToLower() -replace '\s+','-' -replace '—','-' -replace '–','-'
    if ($newName -ne $origName) {
        $origPath = $_.FullName
        $newPath = Join-Path $Root $newName
        if (Test-Path $newPath) {
            Write-Warning "Target path $newPath already exists, skipping rename of $origName"
        } else {
            Write-Host "Renaming '$origName' -> '$newName'"
            Rename-Item -Path $origPath -NewName $newName
            # update git remote if .git exists
            if (Test-Path (Join-Path $newPath ".git")) {
                $sshUrl = "git@github.com:Fatalerorr69/$newName.git"
                try {
                    git -C $newPath remote set-url origin $sshUrl
                    Write-Host "Updated origin for $newName -> $sshUrl"
                } catch {
                    Write-Warning ("Failed to update remote for {0}: {1}" -f $newName, $_.Exception.Message)
                }
            }
        }
    } else {
        Write-Host "No rename needed for $origName"
    }
}

# Update manifest names (lowercase, replace spaces)
$manifest = Join-Path $Root "starcore_manifest.yaml"
if (Test-Path $manifest) {
    $content = Get-Content $manifest -Raw
    $content = $content -replace 'name:\s*(.+)', { "name: " + ($args[0].Groups[1].Value.ToLower() -replace '\s+','-') }
    $content = $content -replace 'path:\s*(.+)', { "path: " + ($args[0].Groups[1].Value -replace '\\\\','\\') -replace '\s+','-' }
    $content | Set-Content $manifest -Encoding UTF8
    Write-Host "Updated manifest: $manifest"
}

# Re-run analyzer and orchestrator if present
$analyzer = Join-Path $Root "starcore_project_analyzer.ps1"
$control = Join-Path $Root "starcore_control.ps1"
if (Test-Path $analyzer) { & $analyzer }
Start-Sleep -Seconds 2
if (Test-Path $control) { & $control -Classify -Readme -Audit -Sync -Root $Root }

Write-Host "Rename and sync completed. Backup at $backup"
