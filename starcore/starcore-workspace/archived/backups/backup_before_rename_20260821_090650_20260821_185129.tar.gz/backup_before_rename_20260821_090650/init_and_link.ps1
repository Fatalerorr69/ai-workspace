# init_and_link.ps1
# Inicializace a propojení lokálních složek s GitHub repozitáři (SSH)
$base = "E:\Git"
$githubOwner = "Fatalerorr69"
$log = Join-Path $base "init_and_link_log.txt"
Remove-Item $log -ErrorAction SilentlyContinue

function Log($t){ $t | Out-File $log -Append -Encoding UTF8; Write-Output $t }

function NormalizeName($name){
    $n = $name.Trim()
    # remove diacritics and special chars
    $n = $n -replace '[^A-Za-z0-9\-_ ]',''
    $n = $n -replace '\s+','-'
    return $n.ToLower()
}

Log "=== INIT AND LINK START ==="
Log "Čas: $(Get-Date)"

Get-ChildItem $base -Directory | ForEach-Object {
    $dir = $_.FullName
    $name = $_.Name
    Log "---- $name ----"
    $gitPath = Join-Path $dir ".git"

    if (-not (Test-Path $gitPath)) {
        Log "No .git found. Inicializuji repozitář..."
        git -C $dir init 2>&1 | Out-File $log -Append -Encoding UTF8
    } else {
        Log ".git exists."
    }

    # detect existing remotes
    $remotes = git -C $dir remote -v 2>$null
    if (-not $remotes) {
        $candidate = NormalizeName $name
        Log "Hledám GitHub repo: $githubOwner/$candidate"
        $exists = $false
        try {
            gh repo view "$githubOwner/$candidate" --json name > $null 2>$null
            $exists = $true
        } catch {}
        if ($exists) {
            $url = "git@github.com:$githubOwner/$candidate.git"
            Log "Nastavuji origin -> $url"
            git -C $dir remote add origin $url 2>&1 | Out-File $log -Append -Encoding UTF8
        } else {
            Log "Repo $candidate nenalezeno na GitHubu. Nechávám bez remote."
        }
    } else {
        Log "Remote existuje:"
        $remotes | Out-File $log -Append -Encoding UTF8
    }

    # ensure safe .gitignore and README
    if (-not (Test-Path (Join-Path $dir ".gitignore"))) {
        "@node_modules`n.env`n.DS_Store`nThumbs.db`n*.log" | Out-File (Join-Path $dir ".gitignore") -Encoding UTF8
        Log ".gitignore vytvořen."
    }

    if (-not (Test-Path (Join-Path $dir "README.md"))) {
        "# $name`n`nKrátký popis projektu." | Out-File (Join-Path $dir "README.md") -Encoding UTF8
        Log "README.md vytvořen."
    }

    # check if repo has commits
    $hasHead = $true
    try {
        git -C $dir rev-parse --verify HEAD > $null 2>&1
    } catch { $hasHead = $false }

    if (-not $hasHead) {
        Log "Repo nemá commit. Přidávám initial commit."
        git -C $dir add . 2>&1 | Out-File $log -Append -Encoding UTF8
        git -C $dir commit -m "Initial commit" 2>&1 | Out-File $log -Append -Encoding UTF8

        $originUrl = (git -C $dir remote get-url origin 2>$null) -join ""
        if ($originUrl) {
            # determine default branch from GitHub if possible
            $candidateRepo = NormalizeName $name
            $branch = "main"
            try {
                $info = gh repo view "$githubOwner/$candidateRepo" --json defaultBranchRef -q '.defaultBranchRef.name' 2>$null
                if ($info) { $branch = $info }
            } catch {}
            git -C $dir branch -M $branch 2>&1 | Out-File $log -Append -Encoding UTF8
            git -C $dir push -u origin $branch 2>&1 | Out-File $log -Append -Encoding UTF8
            Log "Initial commit pushed to origin/$branch"
        } else {
            Log "Initial commit vytvořen lokálně (žádný origin)."
        }
    } else {
        Log "Repo má commit(y)."
    }

    Log ""
}

Log "=== INIT AND LINK END ==="
Log "Log: $log"
