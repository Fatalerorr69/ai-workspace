"""
STARCORE CLI Applications
"""
