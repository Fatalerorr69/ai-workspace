"""
STARCORE Kubernetes Provider
"""
