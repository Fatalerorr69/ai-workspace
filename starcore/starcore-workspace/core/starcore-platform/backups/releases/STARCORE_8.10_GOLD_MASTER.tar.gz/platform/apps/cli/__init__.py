"""
STARCORE Typer CLI
"""
