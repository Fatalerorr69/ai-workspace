# STARCORE scripts test package
