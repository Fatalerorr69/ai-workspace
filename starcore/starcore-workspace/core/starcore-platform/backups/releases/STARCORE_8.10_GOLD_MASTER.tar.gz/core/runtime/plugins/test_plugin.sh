#!/data/data/com.termux/files/usr/bin/bash

echo "STARCORE TEST PLUGIN"

